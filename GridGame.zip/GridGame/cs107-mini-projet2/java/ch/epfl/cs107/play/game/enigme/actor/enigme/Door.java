package ch.epfl.cs107.play.game.enigme.actor.enigme;

import java.util.ArrayList;
import java.util.List;

import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.areagame.actor.AreaEntity;
import ch.epfl.cs107.play.game.areagame.actor.Orientation;
import ch.epfl.cs107.play.game.areagame.actor.Sprite;
import ch.epfl.cs107.play.game.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.game.enigme.handler.EnigmeInteractionVisitor;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.window.Canvas;

public class Door extends AreaEntity {

	private DiscreteCoordinates arrivalCoords;
	private List<DiscreteCoordinates> occupiedCells = new ArrayList<DiscreteCoordinates>();
	private String destination;
	private Sprite sprite;

	private boolean display = true;
	
	public Door(Area area, DiscreteCoordinates position, String destination, DiscreteCoordinates arrivalCoords, DiscreteCoordinates... occupiedCells) {
		super(area, Orientation.DOWN, position);
		this.destination = destination;
		
		//Add array of coords into the list occupiedCells
		for(DiscreteCoordinates coords: occupiedCells) {
			this.occupiedCells.add(coords);
		}
		this.arrivalCoords = arrivalCoords;
		
		//If door leads to same room display closed door
		if(area.getTitle().equalsIgnoreCase(destination)) sprite = new Sprite("door.close.1", 1, 1f, this);
		else sprite = new Sprite("door.open.1", 1, 1f, this);
	}
	
	public Door(Area area, DiscreteCoordinates position, String destination, DiscreteCoordinates arrivalCoords, boolean display, DiscreteCoordinates... occupiedCells) {
		this(area, position, destination, arrivalCoords, occupiedCells);
		this.display = display;
	}
	
	@Override
	public List<DiscreteCoordinates> getCurrentCells() {
		return occupiedCells;
	}

	public String getTitle() {
		return destination;
	}
	
	public DiscreteCoordinates getArrivalCoords() {
		return arrivalCoords;
	}
	
	@Override
	public boolean takeCellSpace() {
		return true;
	}

	@Override
	public boolean isViewInteractable() {
		return false;
	}

	@Override
	public boolean isCellInteractable() {
		return true;
	}

	@Override
	public void draw(Canvas canvas) {
		if(display) sprite.draw(canvas);
	}
	
	@Override
	public void acceptInteraction(AreaInteractionVisitor v) {
		((EnigmeInteractionVisitor) v).interactWith(this);
	}

}
