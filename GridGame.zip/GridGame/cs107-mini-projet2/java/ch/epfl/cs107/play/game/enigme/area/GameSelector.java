package ch.epfl.cs107.play.game.enigme.area;

import ch.epfl.cs107.play.game.enigme.Enigme;
import ch.epfl.cs107.play.game.enigme.actor.enigme.SignalDoor;
import ch.epfl.cs107.play.game.enigme.area.enigme.EnigmeArea;
import ch.epfl.cs107.play.io.FileSystem;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.signal.logic.Logic;
import ch.epfl.cs107.play.window.Window;

public class GameSelector extends EnigmeArea {

	@Override
	public boolean begin(Window window, FileSystem fileSystem) {
		super.begin(window, fileSystem);
		registerActor(new SignalDoor(this, new DiscreteCoordinates(2, 7), "LevelSelector", new DiscreteCoordinates(5, 5), Logic.TRUE, new DiscreteCoordinates(2, 7)));
		registerActor(new SignalDoor(this, new DiscreteCoordinates(7, 7), "Cutscene1", new DiscreteCoordinates(5, 1), Logic.TRUE, new DiscreteCoordinates(7, 7)));
		return true;
	}

	@Override
	public String getTitle() {
		return "GameSelector";
	}

	@Override
	public float getCameraScaleFactor() {
		return Enigme.SCALE_FACTOR;
	}
}
