package ch.epfl.cs107.play.signal.logic;

public class LogicNumber extends LogicSignal {

	Logic[] signals;
	float number;
	
	public LogicNumber(float number, Logic... signals) {
		this.signals = signals;
		this.number = number;
		System.out.println(signals.length);
	}
	
	@Override
	public boolean isOn() {
		if(signals.length > 12 || number < 0 || number > Math.pow(2, signals.length)) return false;
		
		int total = 0;
		
		for(int i = 0; i <= signals.length - 1; i++) {
			if(signals[i] == null || signals[i].isOn() == false);
			else total += Math.pow(2, i);
		}
		if(total == number) return true;
		else return false;
	}

}
