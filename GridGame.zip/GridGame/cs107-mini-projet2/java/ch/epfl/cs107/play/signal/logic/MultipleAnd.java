package ch.epfl.cs107.play.signal.logic;

public class MultipleAnd extends LogicSignal {

	Logic[] signals;
	
	public MultipleAnd(Logic... signals) {
		this.signals = signals;
	}
	
	@Override
	public boolean isOn() {
		for(Logic signal : signals) {
			if(signal == null || signal.isOn() == false) return false;
		}
		return true;
	}

}
