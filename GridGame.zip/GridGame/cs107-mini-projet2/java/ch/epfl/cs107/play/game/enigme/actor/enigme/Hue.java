package ch.epfl.cs107.play.game.enigme.actor.enigme;

import java.util.Collections;
import java.util.List;

import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.areagame.actor.AreaEntity;
import ch.epfl.cs107.play.game.areagame.actor.Orientation;
import ch.epfl.cs107.play.game.areagame.actor.Sprite;
import ch.epfl.cs107.play.game.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.game.enigme.handler.EnigmeInteractionVisitor;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.RegionOfInterest;
import ch.epfl.cs107.play.math.Vector;
import ch.epfl.cs107.play.signal.logic.Logic;
import ch.epfl.cs107.play.window.Canvas;

public class Hue extends AreaEntity implements Logic{

	Sprite sprite;
	Sprite spriteOn;
	
	private boolean activated = false;

	public Hue(Area area, DiscreteCoordinates position, int x, int y) {
		super(area, Orientation.DOWN, position);
		this.sprite = new Sprite("hue.1", 1f, 1f, this, new RegionOfInterest(x, y, 1, 1), Vector.ZERO, 1f, -1);
		this.spriteOn = new Sprite("selected.1", 1f, 1f, this);
	}

	@Override
	public boolean takeCellSpace() {
		return true;
	}

	@Override
	public boolean isViewInteractable() {
		return true;
	}

	@Override
	public boolean isCellInteractable() {
		return false;
	}

	public void goToCell(Vector cellPosition) {
		getArea().enterAreaCells(this, this.getArea().getBehavior().getCell((int) cellPosition.x, (int) cellPosition.y).getCurrentCells());
		getArea().leaveAreaCells(this, getCurrentCells());
		setCurrentPosition(cellPosition, true);
	}

	@Override
	public void draw(Canvas canvas) {
		sprite.draw(canvas);
		if(isOn()) spriteOn.draw(canvas);
	}

	@Override
	public List<DiscreteCoordinates> getCurrentCells() {
		return Collections.singletonList(getCurrentMainCellCoordinates());
	}

	@Override
	public void acceptInteraction(AreaInteractionVisitor v) {
		((EnigmeInteractionVisitor) v).interactWith(this);
	}

	public void activate() {
		activated = (activated) ? false : true;
	}
	
	@Override
	public boolean isOn() {
		return activated;
	}
}
