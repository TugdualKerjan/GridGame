package ch.epfl.cs107.play.game.enigme.area.demo2;

import java.util.Collections;
import java.util.List;

import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.areagame.actor.MovableAreaEntity;
import ch.epfl.cs107.play.game.areagame.actor.Orientation;
import ch.epfl.cs107.play.game.areagame.actor.Sprite;
import ch.epfl.cs107.play.game.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.game.enigme.Demo2Behavior;
import ch.epfl.cs107.play.game.enigme.Demo2Behavior.Demo2CellType;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.Vector;
import ch.epfl.cs107.play.window.Canvas;
import ch.epfl.cs107.play.window.Keyboard;

public class Demo2Player extends MovableAreaEntity {

	/// Animation duration in frame number
	private final static int ANIMATION_DURATION = 8;

	public boolean goingThroughDoor = false;
	private Keyboard keyboard;

	private Sprite sprite;

	public Demo2Player(Area area, Orientation orientation, DiscreteCoordinates coordinates, Keyboard keyboard) {
		super(area, orientation, coordinates);
		sprite = new Sprite("ghost.1", 1, 1f, this) ;
		this.keyboard = keyboard;
	}

	public Demo2Player(Area area, DiscreteCoordinates coordinates, Keyboard keyboard) {
		super(area, Orientation.DOWN, coordinates);
		sprite = new Sprite("ghost.1", 1, 1f, this) ;
		this.keyboard = keyboard;
	}

	public void enterArea(Area area, DiscreteCoordinates position) {
		area.registerActor(this);
		this.setCurrentPosition(new Vector(position.x, position.y));
		resetMotion();
		this.getArea().unregisterActor(this);
		goingThroughDoor = false;
		super.setArea(area);
	}

	@Override
	public List <DiscreteCoordinates > getCurrentCells() {
		return Collections.singletonList(getCurrentMainCellCoordinates()) ;
	}

	@Override
	public boolean takeCellSpace() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isViewInteractable() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isCellInteractable() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void update(float deltaTime) {
		if(keyboard.get(Keyboard.DOWN).isDown()) {
			if(getOrientation() == Orientation.DOWN) {
				move(ANIMATION_DURATION);
			} else {
				setOrientation(Orientation.DOWN);
			}
		}
		if(keyboard.get(Keyboard.UP).isDown()) {
			if(getOrientation() == Orientation.UP) {
				move(ANIMATION_DURATION);
			} else {
				setOrientation(Orientation.UP);
			}
		}
		if(keyboard.get(Keyboard.LEFT).isDown()) {
			if(getOrientation() == Orientation.LEFT) {
				//System.out.println("Going LEFT");
				move(ANIMATION_DURATION);
			} else {
				//System.out.println("Set orientation to LEFT");
				setOrientation(Orientation.LEFT);
			}
		}
		if(keyboard.get(Keyboard.RIGHT).isDown()) {
			if(getOrientation() == Orientation.RIGHT) {
				//System.out.println("Going RIGHT");
				move(ANIMATION_DURATION);
			} else {
				setOrientation(Orientation.RIGHT);
				//System.out.println("Set orientation to RIGHT");
			}
		}
		super.update(deltaTime);
	}

	@Override
	protected boolean move(int framesForMove) {
		super.move(framesForMove);
		Demo2Behavior behavior = (Demo2Behavior) getArea().getBehavior();
		System.out.println(behavior.getCellType(getCurrentMainCellCoordinates().x, getCurrentMainCellCoordinates().y));
		if(behavior.getCellType(getCurrentMainCellCoordinates().x, getCurrentMainCellCoordinates().y) == Demo2CellType.DOOR) {
			goingThroughDoor = true;
		}
		return true;
	}

	@Override
	public void draw(Canvas canvas) {
		sprite.draw(canvas);
	}

	@Override
	public void acceptInteraction(AreaInteractionVisitor v) {
		// TODO Auto-generated method stub
		
	}

}
