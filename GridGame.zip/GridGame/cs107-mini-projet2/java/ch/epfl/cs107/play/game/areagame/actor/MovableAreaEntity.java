package ch.epfl.cs107.play.game.areagame.actor;

import java.util.List;

import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.Vector;


/**
 * MovableAreaEntity are AreaEntity able to move on a grid
 */
public abstract class MovableAreaEntity extends AreaEntity {

	// Indicate if the actor is currently moving
	protected boolean isMoving;

	/// Indicate how many frames the current move is suppose to take
	private int framesForCurrentMove;

	/// The target cell (i.e. where the mainCell will be after the motion)
	private DiscreteCoordinates targetMainCellCoordinates;


	/**
	 * Default MovableAreaEntity constructor
	 * @param area (Area): Owner area. Not null
	 * @param position (Coordinate): Initial position of the entity. Not null
	 * @param orientation (Orientation): Initial orientation of the entity. Not null
	 */
	public MovableAreaEntity(Area area, Orientation orientation, DiscreteCoordinates position) {
		super(area, orientation, position);
		resetMotion();
	}

	/**
	 * Initialize or reset the current motion information
	 */
	public void resetMotion() {
		isMoving = false;
		framesForCurrentMove = 0;
		targetMainCellCoordinates = getCurrentMainCellCoordinates();
	}
	
	protected final List<DiscreteCoordinates> getLeavingCells() {
		return getCurrentCells();
	}

	protected List<DiscreteCoordinates> getEnteringCells() {
		DiscreteCoordinates coords = getCurrentMainCellCoordinates().jump(getOrientation().toVector());
		return this.getArea().getBehavior().getCell(coords.x, coords.y).getCurrentCells();
	}

	/**
	 * 
	 * @param frameForMove (int): number of frames used for simulating motion
	 * @return (boolean): returns true if motion can occur
	 */

	protected boolean move(int framesForMove) {	
		//      Code inutile car la meme chose est verifee dans update()
		//		if(targetMainCellCoordinates == getCurrentMainCellCoordinates()) {
		//			isMoving = false;
		//	}
		if(!isMoving || targetMainCellCoordinates.equals(getCurrentMainCellCoordinates())) {
			if(getArea().enterAreaCells(this, getEnteringCells()) && getArea().leaveAreaCells(this, getLeavingCells())) {
				if(framesForMove < 1) framesForMove = 1;
				else framesForCurrentMove = framesForMove;

				targetMainCellCoordinates = getCurrentMainCellCoordinates().jump(getOrientation().toVector());

				isMoving = true;
				return true;
			} else {
				return false;
			}
		}
		return false;

	}


	@Override
	public void setOrientation(Orientation orientation) {
		if(!isMoving) super.setOrientation(orientation);
	}

	/// MovableAreaEntity implements Actor

	@Override
	public void update(float deltaTime) {
		if(isMoving && !targetMainCellCoordinates.equals(getCurrentMainCellCoordinates())) {
			Vector distance = getOrientation().toVector();
			distance = distance.mul(1.0f / framesForCurrentMove);
			setCurrentPosition(getPosition().add(distance));
		} else {
			resetMotion();
		}
	}

	public void teleport(DiscreteCoordinates coordinates) {
		if(getArea().enterAreaCells(this, getArea().getBehavior().getCell(coordinates.x, coordinates.y).getCurrentCells()) && getArea().leaveAreaCells(this, getLeavingCells())) {
			setCurrentPosition(coordinates.toVector());
		}
	}

	/// Implements Positionable

	@Override
	public Vector getVelocity() {
		// TODO implements me #PROJECT #TUTO
		// the velocity must be computed as the orientation vector (getOrientation().toVector() mutiplied by 
		// framesForCurrentMove
		return null;
	}

	public boolean isMoving() {
		return isMoving;
	}
}
