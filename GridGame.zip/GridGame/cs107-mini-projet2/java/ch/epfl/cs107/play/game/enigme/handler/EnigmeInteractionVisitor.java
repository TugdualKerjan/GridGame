package ch.epfl.cs107.play.game.enigme.handler;

import ch.epfl.cs107.play.game.areagame.actor.AreaEntity;
import ch.epfl.cs107.play.game.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.game.enigme.EnigmeBehavior;
import ch.epfl.cs107.play.game.enigme.actor.Collectable;
import ch.epfl.cs107.play.game.enigme.actor.enigme.Door;
import ch.epfl.cs107.play.game.enigme.actor.enigme.Hue;
import ch.epfl.cs107.play.game.enigme.actor.enigme.MusicPressurePlate;
import ch.epfl.cs107.play.game.enigme.actor.enigme.PressurePlate;
import ch.epfl.cs107.play.game.enigme.actor.enigme.Switch;
import ch.epfl.cs107.play.game.enigme.actor.enigme.WeblinkDoor;
import ch.epfl.cs107.play.game.enigme.actor.memes.Doge;
import ch.epfl.cs107.play.game.enigme.actor.memes.Restart;

public interface EnigmeInteractionVisitor extends AreaInteractionVisitor{

	/**
	 * Simulate and interaction between a enigme Interactors and an enigme Collectable
	 * @param collectable (Collectable), not null
	 */
	default void interactWith(Collectable collectable) {

	}

	/**
	 * Simulate and interaction between a enigme Interactors and an enigme Door
	 * @param door (Door), not null
	 */
	default void interactWith(Door door) {

	}

	/**
	 * Simulate and interaction between a enigme Interactors and an enigme Cell
	 * @param cell (Cell), not null
	 */
	default void interactWith(EnigmeBehavior.EnigmeCell cell) {

	}

	/**
	 * Simulate and interaction between a enigme Interactors and an enigme Switcher
	 * @param switcher (Switcher), not null
	 */
	default void interactWith(Switch switcher) {

	}

	/**
	 * Simulate and interaction between a enigme Interactors and an enigme Plate
	 * @param plate (Plate), not null
	 */
	default void interactWith(PressurePlate plate) {

	}

	/**
	 * Simulate and interaction between a enigme Interactors and an enigme Plate
	 * @param plate (Plate), not null
	 */
	default void interactWith(Restart restart) {

	}

	default void interactWith(AreaEntity entity) {

	}

	default void interactWith(Hue color) {

	}

	default void interactWith(Doge doge) {

	}

	default void interactWith(MusicPressurePlate music) {

	}

	default void interactWith(WeblinkDoor door) {
		
	}
}
