package ch.epfl.cs107.play.game.areagame.actor;

import ch.epfl.cs107.play.math.Positionable;
import ch.epfl.cs107.play.math.RegionOfInterest;
import ch.epfl.cs107.play.math.Vector;
import ch.epfl.cs107.play.window.Canvas;

public class Animation {

	Sprite[][] sprites;
	Orientation lastOrientation;
	int animationCycle = 0;
	int framesPerImage;

	public Animation(int framesPerImage, String spriteName, float width, float height, Positionable parent, Vector anchor, int amountOfSpritesWide, int amountOfSpritesHigh, int spriteWidth, int spriteHeight) {
		this.framesPerImage = framesPerImage;
		this.sprites = new Sprite[amountOfSpritesWide][amountOfSpritesHigh];
		for(int x = 0; x < amountOfSpritesWide; x++) {
			for(int y = 0; y < amountOfSpritesHigh; y++) {
				sprites[x][y] = new Sprite(spriteName, width, height, parent, new RegionOfInterest(x * spriteWidth, y * spriteHeight, spriteWidth, spriteHeight), anchor);
			}
		}
	}

	public Animation(int framesPerImage, float width, float height, Positionable parent, String... spriteName) {
		this.framesPerImage = framesPerImage;
		this.sprites = new Sprite[1][spriteName.length];
		for(int i = 0; i < spriteName.length; i++) {
			sprites[0][i] = new Sprite(spriteName[i], width, height, parent);
		}
	}
	
	public void draw(Canvas canvas, Orientation orientation, boolean isMoving) {
		//If the orientation has changed since last call reset animation cycle
		if(lastOrientation != orientation) {
			animationCycle = 0;
			lastOrientation = orientation;
		}
		
		//Which frame to display
		int frameToGet = (int) animationCycle / framesPerImage;
		
		//Animation depends on which way the Actor is facing
		switch(orientation) {
		case DOWN: {
			if(frameToGet == sprites[0].length || (!isMoving && frameToGet % 2 != 0)) {
				animationCycle = 0;
				frameToGet = (int) animationCycle / framesPerImage;
			}
			sprites[0][frameToGet].draw(canvas);
			animationCycle++;
			break;
		}

		case LEFT: {
			if(frameToGet == sprites[1].length || (!isMoving && frameToGet % 2 != 0)) {
				animationCycle = 0;
				frameToGet = (int) animationCycle / framesPerImage;
			}
			sprites[1][frameToGet].draw(canvas);
			animationCycle++;
			break;
		}

		case UP: {
			if(frameToGet == sprites[2].length || (!isMoving && frameToGet % 2 != 0)) {
				animationCycle = 0;
				frameToGet = (int) animationCycle / framesPerImage;
			}
			sprites[2][frameToGet].draw(canvas);
			animationCycle++;
			break;
		}

		case RIGHT: {
			if(frameToGet == sprites[3].length || (!isMoving && frameToGet % 2 != 0)) {
				animationCycle = 0;
				frameToGet = (int) animationCycle / framesPerImage;
			}
			sprites[3][frameToGet].draw(canvas);
			animationCycle++;
			break;
		}

		default: {
			if(frameToGet == sprites[0].length) {
				animationCycle = 0;
				frameToGet = (int) animationCycle / framesPerImage;
			}
			sprites[0][frameToGet].draw(canvas);
			animationCycle++;
			break;
		}
		}
	}
}
