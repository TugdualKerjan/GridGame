package ch.epfl.cs107.play.game.enigme.actor.enigme;

import java.util.Collections;
import java.util.List;

import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.areagame.actor.Animation;
import ch.epfl.cs107.play.game.areagame.actor.AreaEntity;
import ch.epfl.cs107.play.game.areagame.actor.Orientation;
import ch.epfl.cs107.play.game.areagame.actor.Sprite;
import ch.epfl.cs107.play.game.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.game.enigme.handler.EnigmeInteractionVisitor;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.signal.logic.Logic;
import ch.epfl.cs107.play.window.Canvas;

public class Switch extends AreaEntity implements Logic{

	private boolean activated = false;
	
	private Sprite spriteOff;
	private Animation animator;
	
	public Switch(Area area, DiscreteCoordinates position, String spriteOffName, String... spriteOnName) {
		super(area, Orientation.DOWN, position);
		this.animator = new Animation(20, 1f, 1f, this, spriteOnName);
		this.spriteOff = new Sprite(spriteOffName, 1, 1f, this);
	}
	
	public Switch(Area area, DiscreteCoordinates position, String spriteOnName) {
		super(area, Orientation.DOWN, position);
		this.animator = new Animation(20, 1f, 1f, this, spriteOnName);
	}
	
	@Override
	public List<DiscreteCoordinates> getCurrentCells() {
		return Collections.singletonList(getCurrentMainCellCoordinates());
	}

	@Override
	public boolean takeCellSpace() {
		return true;
	}

	@Override
	public boolean isViewInteractable() {
		return false;
	}

	@Override
	public boolean isCellInteractable() {
		return true;
	}

	@Override
	public void acceptInteraction(AreaInteractionVisitor v) {
		((EnigmeInteractionVisitor) v).interactWith(this);
	}

	@Override
	public void draw(Canvas canvas) {
		if(activated) {
			animator.draw(canvas, getOrientation(), true);
		} else {
			if(spriteOff != null)
			spriteOff.draw(canvas);
		}
	}
	
	public void activate() {
		activated = (activated) ? false : true;
	}

	@Override
	public boolean isOn() {
		return activated;
	}

}
