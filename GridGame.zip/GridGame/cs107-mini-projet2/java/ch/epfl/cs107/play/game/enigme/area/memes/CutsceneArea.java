package ch.epfl.cs107.play.game.enigme.area.memes;

import java.util.ArrayList;

import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.areagame.actor.Background;
import ch.epfl.cs107.play.game.enigme.Enigme;
import ch.epfl.cs107.play.game.enigme.EnigmeBehavior;
import ch.epfl.cs107.play.game.enigme.actor.Dialog;
import ch.epfl.cs107.play.io.FileSystem;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.Transform;
import ch.epfl.cs107.play.math.Vector;
import ch.epfl.cs107.play.window.Keyboard;
import ch.epfl.cs107.play.window.Window;

public abstract class CutsceneArea extends Area{

	private ArrayList<Scene> scenes = new ArrayList<Scene>();
	public boolean passToNextArea = false;
	int dialogToDisplay = 0;
	private Window window;
	int framesPassed = 0;

	@Override
	public void update(float deltaTime) {
		framesPassed++;

		//If all scenes have passed then proceed to nextArea
		if(scenes.size() == 0) {
			passToNextArea = true;
			return;
		}

		//Scale the window
		Transform viewTransform = Transform.I.scaled(getCameraScaleFactor()).translated(new Vector(getWidth()/2, getHeight()/2));
		window.setRelativeTransform(viewTransform);

		//Draw the scenes
		draw(scenes.get(0));

		//Next dialog / scene when key is pressed
		if(window.getKeyboard().get(Keyboard.L).isPressed() || (scenes.get(0).basedOnFrames != 0 &&framesPassed >= scenes.get(0).basedOnFrames)) {
			if(dialogToDisplay == scenes.get(0).dialog.length - 1) {
				scenes.remove(0);
				dialogToDisplay = 0;
				framesPassed = 0;
			}
			else dialogToDisplay++;
		}

	}

	private void draw(Scene scene) {
		scene.background.draw(window);
		if(scene.dialog != null) {
			//If there are multiple dialog to display then divide available time between them
			scene.dialog[dialogToDisplay].draw(window);
		}
	}

	@Override
	public boolean begin(Window window, FileSystem fileSystem) {
		super.begin(window, fileSystem);
		this.window = window;

		//All cutscenes have standard behavior
		setBehavior(new EnigmeBehavior(window, "Cutscene"));
		return true;
	}

	public void addScene(Background background) {
		scenes.add(new Scene(background));
	}

	public void addScene(Background background, Dialog... text) {
		scenes.add(new Scene(background, text));
	}

	public void addScene(Background background, int basedOnFrames, Dialog... text) {
		scenes.add(new Scene(background, basedOnFrames, text));
	}

	private class Scene {

		public Dialog[] dialog;
		public Background background;
		public int basedOnFrames;

		Scene(Background b) {
			background = b;
		}

		Scene(Background b, Dialog... text) {
			this(b);
			dialog = text;
		}

		Scene(Background b, int basedOnFrames, Dialog... text) {
			this(b, text);
			this.basedOnFrames = basedOnFrames;
		}
	}

	@Override
	public abstract float getCameraScaleFactor();

	public abstract DiscreteCoordinates getArrivalCoords();

	public abstract String getNextTitle();

}
