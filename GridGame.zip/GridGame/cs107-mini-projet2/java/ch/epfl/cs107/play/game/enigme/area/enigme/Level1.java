package ch.epfl.cs107.play.game.enigme.area.enigme;

import ch.epfl.cs107.play.game.enigme.Enigme;
import ch.epfl.cs107.play.game.enigme.actor.enigme.Door;
import ch.epfl.cs107.play.io.FileSystem;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.window.Window;

public class Level1 extends EnigmeArea {

	@Override
	public boolean begin(Window window, FileSystem fileSystem) {
		super.begin(window, fileSystem);
		registerActor(new Door(this, new DiscreteCoordinates(5, 0), "LevelSelector", new DiscreteCoordinates(1, 6), new DiscreteCoordinates(5, 0)));
		return true;
	}

	@Override
	public String getTitle() {
		return "Level1";
	}

	@Override
	public float getCameraScaleFactor() {
		// TODO Auto-generated method stub
		return Enigme.SCALE_FACTOR;
	}
}
