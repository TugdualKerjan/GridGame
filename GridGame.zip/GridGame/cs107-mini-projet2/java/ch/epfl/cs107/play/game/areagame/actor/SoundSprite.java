package ch.epfl.cs107.play.game.areagame.actor;

import ch.epfl.cs107.play.game.actor.SoundAcoustics;
import ch.epfl.cs107.play.window.Audio;

public class SoundSprite extends SoundAcoustics {

	/**
	 * Creates a new sound sprite
	 * @param name (String): sound name, not null
	 */
	public SoundSprite(String name) {
		super(name);
	}

	public void play(Audio audio) {
		super.bip(audio);
	}
}
