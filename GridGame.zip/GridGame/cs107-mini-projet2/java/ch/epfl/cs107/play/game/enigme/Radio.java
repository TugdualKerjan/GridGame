package ch.epfl.cs107.play.game.enigme;

import ch.epfl.cs107.play.game.areagame.actor.SoundSprite;
import ch.epfl.cs107.play.game.areagame.io.ResourcePath;
import ch.epfl.cs107.play.window.Audio;

public enum Radio {
	
	RICK_ASTLEY("rickAstley"),
	DIALOG_NEXT("dialogNext"),
	NOTE1("note1"),
	NOTE2("note2"),
	NOTE3("note3"),
	NOTE4("note4");
	
	private SoundSprite sound;
	
	Radio(String name) {
		sound = new SoundSprite(ResourcePath.getSounds(name));
		sound.shouldBeStarted();
	}
	
	public void play(Audio audio, boolean playAgain) {
		sound.play(audio);
		if(playAgain) sound.shouldBeStarted();
	}
}
