package ch.epfl.cs107.play.game.enigme.actor;

import java.util.Collections;
import java.util.List;

import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.areagame.actor.AreaEntity;
import ch.epfl.cs107.play.game.areagame.actor.Orientation;
import ch.epfl.cs107.play.game.areagame.actor.Sprite;
import ch.epfl.cs107.play.game.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.game.enigme.handler.EnigmeInteractionVisitor;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.signal.logic.Logic;
import ch.epfl.cs107.play.window.Canvas;

public class Collectable extends AreaEntity implements Logic{

	private boolean activated = false;

	private Sprite sprite;

	public Collectable(Area area, DiscreteCoordinates position) {
		super(area, Orientation.DOWN, position);
	}

	public void setSprite(Sprite sprite) { 
		this.sprite = sprite;
	}
	
	@Override
	public List<DiscreteCoordinates> getCurrentCells() {
		return  Collections.singletonList(getCurrentMainCellCoordinates());
	}

	@Override
	public boolean takeCellSpace() {
		return isOn();
	}
	
	@Override
	public boolean isViewInteractable() {
		return !isOn();
	}

	@Override
	public boolean isCellInteractable() {
		return false;
	}

	@Override
	public void acceptInteraction(AreaInteractionVisitor v) {
		((EnigmeInteractionVisitor) v).interactWith(this);
	}

	public void activate() {
		activated = true;
	}
	
	@Override
	public void draw(Canvas canvas) {
		if(!isOn()) sprite.draw(canvas);
	}

	@Override
	public boolean isOn() {
		return activated;
	}

}
