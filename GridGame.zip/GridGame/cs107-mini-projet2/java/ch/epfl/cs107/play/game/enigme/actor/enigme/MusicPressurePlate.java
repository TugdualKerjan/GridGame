package ch.epfl.cs107.play.game.enigme.actor.enigme;

import java.util.Collections;
import java.util.List;

import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.areagame.actor.AreaEntity;
import ch.epfl.cs107.play.game.areagame.actor.Orientation;
import ch.epfl.cs107.play.game.areagame.actor.Sprite;
import ch.epfl.cs107.play.game.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.game.enigme.Enigme;
import ch.epfl.cs107.play.game.enigme.Radio;
import ch.epfl.cs107.play.game.enigme.handler.EnigmeInteractionVisitor;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.signal.logic.Logic;
import ch.epfl.cs107.play.window.Audio;
import ch.epfl.cs107.play.window.Canvas;

public class MusicPressurePlate extends AreaEntity implements Logic {
	
	//Keeps in mind how long it has lasted
	protected int activatedFrames = 0;
	
	private boolean activated = false;
	
	protected Sprite spriteOn;
	protected Sprite spriteOff;
	
	private String noteToPlay;

	public MusicPressurePlate(Area area, DiscreteCoordinates position, String note, String spriteOnName, String spriteOffName) {
		super(area, Orientation.DOWN, position);
		spriteOn = new Sprite(spriteOnName, 1, 1f, this);
		spriteOff = new Sprite(spriteOffName, 1, 1f, this);
		noteToPlay = note;
	}
	
	@Override
	public boolean takeCellSpace() {
		return false;
	}
	
	@Override
	public boolean isViewInteractable() {
		return true;
	}

	@Override
	public boolean isCellInteractable() {
		return false;
	}

	@Override
	public List<DiscreteCoordinates> getCurrentCells() {
		return Collections.singletonList(getCurrentMainCellCoordinates());
	}

	@Override
	public void acceptInteraction(AreaInteractionVisitor v) {
		((EnigmeInteractionVisitor) v).interactWith(this);
	}

	@Override
	public void draw(Canvas canvas) {
		if(activatedFrames > 0) {
			spriteOn.draw(canvas);
		} else spriteOff.draw(canvas);
		if(activated) Radio.valueOf(noteToPlay).play((Audio) canvas, true);
		
	}

	public void activate() {
		activatedFrames = Enigme.FRAMERATE * 1;
		activated = true;
	}
	
	
	@Override
	public void update(float deltaTime) {
		super.update(deltaTime);
		if(activatedFrames > 0) activatedFrames--;
	}
	
	@Override
	public boolean isOn() {
		return activated;
	}

	@Override
	public void setOff() {
		activated = false;
	}

}
