package ch.epfl.cs107.play.game.enigme.actor.enigme.switches;

import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.enigme.actor.enigme.Switch;
import ch.epfl.cs107.play.math.DiscreteCoordinates;

public class PressureSwitch extends Switch{
	
	public PressureSwitch(Area area, DiscreteCoordinates position) {
		super(area, position, "GroundLightOff", "GroundLightOn");
	}
	
}
