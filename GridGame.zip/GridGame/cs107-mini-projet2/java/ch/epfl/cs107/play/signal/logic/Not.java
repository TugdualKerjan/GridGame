package ch.epfl.cs107.play.signal.logic;

public class Not extends LogicSignal{

	Logic s;
	
	public Not(Logic signal) {
		s = signal;
	}
	
	@Override
	public boolean isOn() {
		if(s != null && s.isOn() == false) {
			return false;
		} else {
			return true;
		}
	}

}
