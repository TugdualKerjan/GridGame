package ch.epfl.cs107.play.game.enigme;

import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.areagame.AreaGame;
import ch.epfl.cs107.play.game.enigme.actor.EnigmePlayer;
import ch.epfl.cs107.play.game.enigme.actor.memes.Doge;
import ch.epfl.cs107.play.game.enigme.area.GameSelector;
import ch.epfl.cs107.play.game.enigme.area.enigme.Level1;
import ch.epfl.cs107.play.game.enigme.area.enigme.Level2;
import ch.epfl.cs107.play.game.enigme.area.enigme.Level3;
import ch.epfl.cs107.play.game.enigme.area.enigme.LevelSelector;
import ch.epfl.cs107.play.game.enigme.area.memes.Cable;
import ch.epfl.cs107.play.game.enigme.area.memes.Cutscene1;
import ch.epfl.cs107.play.game.enigme.area.memes.CutsceneArea;
import ch.epfl.cs107.play.game.enigme.area.memes.Page1;
import ch.epfl.cs107.play.game.enigme.area.memes.Page2;
import ch.epfl.cs107.play.game.enigme.area.memes.Page3;
import ch.epfl.cs107.play.io.FileSystem;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.window.Keyboard;
import ch.epfl.cs107.play.window.Window;

/**
 * AreaGame is a type of Game displayed in a (MxN) Grid called Area
 * An AreaGame has multiple Areas
 */
public class Enigme extends AreaGame {

	public final static int SCALE_FACTOR = 22;
	public final static int FRAMERATE = 72;

	//Game paused?
	boolean paused = false;

	//Create player
	EnigmePlayer player;
	
	//Create doge
	Doge doge;

	Keyboard keyboard;
	Window window;
	FileSystem fileSystem;

	//Create rooms
	GameSelector gameSelector = new GameSelector();
	LevelSelector levelSelector = new LevelSelector();
	Level1 level1 = new Level1();
	Level2 level2 = new Level2();
	Level3 level3 = new Level3();
	
	
	Cutscene1 cutscene1 = new Cutscene1();
	Cable cable = new Cable();
	Page1 page1 = new Page1();
	Page2 page2 = new Page2();
	Page3 page3 = new Page3();

	@Override
	public boolean begin(Window window, FileSystem fileSystem) {
		super.begin(window, fileSystem);
		this.window = window;
		this.fileSystem = fileSystem;
		this.keyboard = window.getKeyboard();

		addArea(gameSelector);
		
		addArea(cutscene1);
		addArea(cable);
		addArea(page1);
		addArea(page2);
		addArea(page3);
		
		addArea(levelSelector);
		addArea(level1);
		addArea(level2);
		addArea(level3);

		player = new EnigmePlayer(page1, new DiscreteCoordinates(5, 5), window.getKeyboard());
		setCurrentArea(page1.getTitle(), false);


		page1.setViewCandidate(player);
		page1.registerActor(player);
		return true;
	}

	@Override
	public int getFrameRate() {
		return FRAMERATE;
	}
	
	@Override
	public void update(float deltaTime) {
		//PAUSING
		if(keyboard.get(Keyboard.SPACE).isPressed()) {
			if(!paused && !player.goingThroughDoor && !player.isMoving()) {
				window.setPaused(true);
				player.getArea().suspend(); 
				paused = true;
			}
			else {
				player.getArea().resume(window, fileSystem);
				paused = false;
				window.setPaused(false);
			}
		}
		
		if(getCurrentArea() instanceof CutsceneArea && ((CutsceneArea) getCurrentArea()).passToNextArea) {
			CutsceneArea cutscene = ((CutsceneArea) getCurrentArea());
			Area newArea = setCurrentArea(cutscene.getNextTitle(), false);
			player.enterArea(newArea, cutscene.getArrivalCoords());
			newArea.setViewCandidate(player);
		}

		//CHECK IF PLAYER GOING THROUGH DOOR
		if(player.goingThroughDoor) {
			player.getArea().unregisterActor(player);
			if(doge!=null) player.getArea().unregisterActor(doge);
			Area newArea = setCurrentArea(player.passedDoor().getTitle(), false);
			if(!(newArea instanceof CutsceneArea)) {
				player.enterArea(newArea, player.passedDoor().getArrivalCoords());
				newArea.setViewCandidate(player);
			}
			player.goingThroughDoor = false;
		}
		
		if(player.restarting) {
			DiscreteCoordinates coords = new DiscreteCoordinates((int)player.getPosition().x, (int)player.getPosition().y);
			player.getArea().unregisterActor(player);
			Area newArea = setCurrentArea(player.getArea().getTitle(), false);
			newArea.restart();
			player.enterArea(newArea, coords);
			newArea.setViewCandidate(player);
			player.restarting = false;
		}

		super.update(deltaTime);
	}

	@Override
	public String getTitle() {
		// TODO Auto-generated method stub
		return "Enigme";
	}

}
