package ch.epfl.cs107.play.signal.logic;

import ch.epfl.cs107.play.signal.Signal;

public interface Logic extends Signal{

	//Always returns true for isOn()
	Logic TRUE = new Logic() {
		@Override
		public boolean isOn() {
			return true;
		}
	};
	
	//Idem but returns false
	Logic FALSE = new Logic() {
		@Override
		public boolean isOn() {
			return false;
		}
	};

	boolean isOn();

	default float getIntensity() {
		if(isOn()) return 1f;
		else return 0f;
	}

	@Override
	default float getIntensity(float t) {
		return getIntensity();
	}

	default void setOff() {
		
	}

}
