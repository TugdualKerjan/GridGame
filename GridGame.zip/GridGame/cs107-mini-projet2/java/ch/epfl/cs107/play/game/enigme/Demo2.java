package ch.epfl.cs107.play.game.enigme;

import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.areagame.AreaGame;
import ch.epfl.cs107.play.game.enigme.area.demo2.Demo2Player;
import ch.epfl.cs107.play.game.enigme.area.demo2.Room0;
import ch.epfl.cs107.play.game.enigme.area.demo2.Room1;
import ch.epfl.cs107.play.io.FileSystem;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.Vector;
import ch.epfl.cs107.play.window.Window;


/**
 * AreaGame is a type of Game displayed in a (MxN) Grid called Area
 * An AreaGame has multiple Areas
 */
public class Demo2 extends AreaGame {

	public final static int SCALE_FACTOR = 22;
	
	//Create player
	Demo2Player player;
	
	//Create rooms
	Room0 room0 = new Room0();
	Room1 room1 = new Room1();
	
	@Override
	public boolean begin(Window window, FileSystem fileSystem) {
		super.begin(window, fileSystem);
		
		addArea(room0);
		addArea(room1);
		setCurrentArea(room0.getTitle(), false);
		
		player = new Demo2Player(room0, new DiscreteCoordinates(5, 5), window.getKeyboard());
		
		room0.registerActor(player);
		room0.setViewCandidate(player);
	
		return true;
	}

	@Override
	public int getFrameRate() {
		// TODO Auto-generated method stub
		return 30;
	}

	@Override
	public void update(float deltaTime) {
		if(player.goingThroughDoor) {
			if(player.getArea() == room0) {
				
				System.out.println("Player going from room0 to room1");		
				Area newArea = setCurrentArea(room1.getTitle(), false);
				player.enterArea(newArea, new DiscreteCoordinates(5, 2));
				room1.setViewCandidate(player);
			} else if (player.getArea() == room1) {
				
				System.out.println("Player going from room1 to room0");		
				Area newArea = setCurrentArea(room0.getTitle(), false);
				player.enterArea(newArea, new DiscreteCoordinates(5, 5));
				room0.setViewCandidate(player);
			}
		}
		super.update(deltaTime);
	}
	
	@Override
	public String getTitle() {
		// TODO Auto-generated method stub
		return "Demo2";
	}

}
