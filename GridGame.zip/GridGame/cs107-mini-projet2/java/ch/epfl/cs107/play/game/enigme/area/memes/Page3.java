package ch.epfl.cs107.play.game.enigme.area.memes;

import ch.epfl.cs107.play.game.enigme.Enigme;
import ch.epfl.cs107.play.game.enigme.actor.Dialog;
import ch.epfl.cs107.play.game.enigme.actor.enigme.Door;
import ch.epfl.cs107.play.game.enigme.actor.memes.Restart;
import ch.epfl.cs107.play.game.enigme.area.enigme.EnigmeArea;
import ch.epfl.cs107.play.io.FileSystem;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.window.Window;

public class Page3  extends EnigmeArea{

	Window window;

	//Initial dialog
	Dialog dialog1 = new Dialog("", "dialog.3", this);
	Dialog dialog2 = new Dialog("Do it by recreating the order of the sounds using the buttons on the left!", "dialog.3", this);
	Dialog dialog3 = new Dialog("To replay the tune, use the button on the right!", "dialog.3", this);
	int startExplain;

	//End dialog
	Dialog dialog4 = new Dialog("AWESOME! Thanks to your help you liberated Rick Astley!", "dialog.3", this);
	Dialog dialog5 = new Dialog("I would play you Never Gonna give you up but unfortunatley", "dialog.3", this);
	Dialog dialog6 = new Dialog("The file is too big for the 1.5MB limit, I had to remove it", "dialog.3", this);
	Dialog dialog7 = new Dialog("Go on the home tile to go back to start", "dialog.3", this);
	int endExplain = 0;

	@Override
	public boolean begin(Window window, FileSystem fileSystem) {
		super.begin(window, fileSystem);
		this.window = window;
		startExplain = Enigme.FRAMERATE * 17;

		//Home and refresh
		registerActor(new Door(this, new DiscreteCoordinates(1, 18), "GameSelector", new DiscreteCoordinates(3, 6), false, new DiscreteCoordinates(1, 18)));
		registerActor(new Restart(this, new DiscreteCoordinates(2, 18)));


		return true;

	}

	@Override
	public String getTitle() {
		return "Webpage.3";
	}

	@Override
	public float getCameraScaleFactor() {
		return Enigme.SCALE_FACTOR;
	}


	@Override
	public void update(float deltaTime) {	
		super.update(deltaTime);
		draw();
	}

	private void draw() {
		if(startExplain > Enigme.FRAMERATE * 8) {
			noMovement = true;
			dialog1.draw(window);
			startExplain--;
		} else if(startExplain <= Enigme.FRAMERATE * 9 && startExplain > Enigme.FRAMERATE * 4) {
			dialog2.draw(window);
			startExplain--;
		} else if(startExplain <= Enigme.FRAMERATE * 4 && startExplain > Enigme.FRAMERATE * 0 + 1) {
			dialog3.draw(window);
			startExplain--;
		} if(startExplain == 1) {
			noMovement = false;
			startExplain--;
		} 

		if(endExplain > Enigme.FRAMERATE * 12) {
			noMovement = true;
			dialog4.draw(window);
			endExplain--;
		} else if(endExplain <= Enigme.FRAMERATE * 12 && endExplain > Enigme.FRAMERATE * 8) {
			dialog5.draw(window);
			endExplain--;
		} else if(endExplain <= Enigme.FRAMERATE * 8 && endExplain > Enigme.FRAMERATE * 4) {
			dialog6.draw(window);
			endExplain--;
		} else if(endExplain <= Enigme.FRAMERATE * 4 && endExplain > Enigme.FRAMERATE * 0 + 1) {
			dialog7.draw(window);
			endExplain--;
		} if(endExplain == 1) {
			noMovement = false;
			endExplain--;
		} 
	}
}
