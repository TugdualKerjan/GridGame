package ch.epfl.cs107.play.game.enigme.area.memes;

import ch.epfl.cs107.play.game.areagame.actor.Orientation;
import ch.epfl.cs107.play.game.enigme.Enigme;
import ch.epfl.cs107.play.game.enigme.actor.Dialog;
import ch.epfl.cs107.play.game.enigme.actor.Sensei;
import ch.epfl.cs107.play.game.enigme.actor.enigme.Door;
import ch.epfl.cs107.play.game.enigme.area.enigme.EnigmeArea;
import ch.epfl.cs107.play.io.FileSystem;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.Transform;
import ch.epfl.cs107.play.math.Vector;
import ch.epfl.cs107.play.window.Window;

public class Cable extends EnigmeArea {

	Window window;
	int startExplain = Enigme.FRAMERATE * 10;
	
	Dialog dialog1 = new Dialog("Move with the arrow keys!", "dialog.3", this);
	Dialog dialog2 = new Dialog("Interact with other entities by looking at them and pressing L", "dialog.3", this);
	Dialog dialog3 = new Dialog("Pause the game by pressing SPACE", "dialog.3", this);
	
	@Override
	public boolean begin(Window window, FileSystem fileSystem) {
		super.begin(window, fileSystem);
		this.window = window;
		registerActor(new Door(this, new DiscreteCoordinates(20, 33), "Webpage.1", new DiscreteCoordinates(3, 6), false, new DiscreteCoordinates(20, 33)));
		registerActor(new Sensei(this, Orientation.DOWN, new DiscreteCoordinates(20, 25), 
				new Dialog("Hello young one. I am sensei, I have called on you to save the memes!", "dialog.3", this),
				new Dialog("We are going through the deep sea internet cables to a webpage. ", "dialog.3", this),
				new Dialog("Things you can do on the webpage:", "dialog.3", this),
				new Dialog("Go to the 'home' tile will bring you back to the main menu", "dialog.3", this),
				new Dialog("Go to the 'reload' tile will reset the level", "dialog.3", this),
				new Dialog("Before destroying Article 13, you'll need to collect 3 god-tier memes.", "dialog.3", this),
				new Dialog("Fail, and the world blows up. (Because I said so)", "dialog.3", this),
				new Dialog("Good luck!", "dialog.3", this)));
		return true;
	}

	@Override
	public String getTitle() {
		return "Cable.1";
	}

	@Override
	public float getCameraScaleFactor() {
		return Enigme.SCALE_FACTOR * 0.7f;
	}
	
	@Override
	public void update(float deltaTime) {
		super.update(deltaTime);
		draw();
		window.setRelativeTransform(Transform.I.scaled(getCameraScaleFactor()).translated(new Vector((float) Math.random() / 30 + getViewCenter().x, (float) Math.random() / 30 + getViewCenter().y))) ;
	}
	
	private void draw() {
		if(startExplain > Enigme.FRAMERATE * 7) {
			noMovement = true;
			dialog1.draw(window);
			startExplain--;
		} else if(startExplain > Enigme.FRAMERATE * 3 && startExplain <= Enigme.FRAMERATE * 7) {
			dialog2.draw(window);
			System.out.println(startExplain);
			startExplain--;
		} else if(startExplain > Enigme.FRAMERATE * 0 + 1 && startExplain <= Enigme.FRAMERATE * 3) {
			dialog3.draw(window);
			startExplain--;
		} else if(startExplain == 1) {
			noMovement = false;
			startExplain--;
		}
	}
}
