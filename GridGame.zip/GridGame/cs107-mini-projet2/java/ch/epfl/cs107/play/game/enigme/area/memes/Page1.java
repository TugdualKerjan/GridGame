package ch.epfl.cs107.play.game.enigme.area.memes;

import java.util.Random;

import ch.epfl.cs107.play.game.areagame.actor.Orientation;
import ch.epfl.cs107.play.game.enigme.Enigme;
import ch.epfl.cs107.play.game.enigme.actor.Dialog;
import ch.epfl.cs107.play.game.enigme.actor.enigme.Door;
import ch.epfl.cs107.play.game.enigme.actor.enigme.Hue;
import ch.epfl.cs107.play.game.enigme.actor.memes.Doge;
import ch.epfl.cs107.play.game.enigme.actor.memes.Restart;
import ch.epfl.cs107.play.game.enigme.area.enigme.EnigmeArea;
import ch.epfl.cs107.play.io.FileSystem;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.Vector;
import ch.epfl.cs107.play.window.Window;

public class Page1 extends EnigmeArea {

	Hue[][] colors = new Hue[6][6];
	DiscreteCoordinates[][] colorCheck = new DiscreteCoordinates[6][6];
	Dialog dialog1 = new Dialog("Beautiful isn't it?", "dialog.3", this);
	Dialog dialog2 = new Dialog("SYKE! Redo the pattern!", "dialog.3", this);
	Dialog dialog3 = new Dialog("Select a tile with L, select another to swap their places!", "dialog.3", this);
	int startExplain;
	Window window;

	@Override
	public boolean begin(Window window, FileSystem fileSystem) {
		super.begin(window, fileSystem);
		this.window = window;
		startExplain = Enigme.FRAMERATE * 12;

		registerActor(new Door(this, new DiscreteCoordinates(1, 18), "GameSelector", new DiscreteCoordinates(3, 6), false, new DiscreteCoordinates(1, 18)));
		registerActor(new Restart(this, new DiscreteCoordinates(2, 18)));
		for(int x = 0; x < colors.length; x++) {
			for(int y = 0; y < colors[x].length; y++) {
				colors[x][y] = new Hue(this, new DiscreteCoordinates(7 + x, 7 + y), x, y);
				registerActor(colors[x][y]);
				colorCheck[x][y] = new DiscreteCoordinates(7 + x, 7 + y);
			}
		}
		return true;
	}

	@Override
	public void update(float deltaTime) {
		super.update(deltaTime);
		draw();
	}

	private void draw() {
		if(startExplain > Enigme.FRAMERATE * 7) { 
			noMovement = true;
			dialog1.draw(window);
			startExplain--;
		} else if(startExplain > Enigme.FRAMERATE * 5 && startExplain <= Enigme.FRAMERATE * 7) {
			randomizeHues();
			startExplain--;
		}  else if(startExplain > Enigme.FRAMERATE * 3 && startExplain <= Enigme.FRAMERATE * 5) { 
			dialog2.draw(window);
			startExplain--;
		} else if(startExplain > 1 && startExplain <= Enigme.FRAMERATE * 3) { 
			dialog3.draw(window);
			startExplain--;
		} else if (startExplain == 1) {
			noMovement = false;
			startExplain--;
		}
	}

	//Check if two of the color tile are activated and if so swap them and check if all are in the right place and if so register the actor doge
	public void checkIfTwoHuesActivated() {
		Hue hue = null;
		for(int x = 0; x < colors.length; x++) {
			for(int y = 0; y < colors[x].length; y++) {
				Hue color = colors[x][y];
				if(color.isOn()) {
					//If its the first hue on, then set it to hue
					if(hue == null) hue = color;
					//Otherwise it's the second so perform the switch between them
					else {
						Vector coords1 = hue.getPosition();
						Vector coords2 = color.getPosition();
						hue.goToCell(coords2);
						color.goToCell(coords1);
						color.activate();
						hue.activate();
					}
				}
			}
		}
		//check if both arrays are exactly the same
		for(int x = 0; x < colors.length; x++) {
			for(int y = 0; y < colors[x].length; y++) {
				if(!colors[x][y].getPosition().equals(colorCheck[x][y].toVector())) {
					return;
				}
			}
		}
		//If they are then proceed to add pepe image, and remove all tile entities
		for(int x = 0; x < colors.length; x++) {
			for(int y = 0; y < colors[x].length; y++) {
				unregisterActor(colors[x][y]);
			}
		}

		registerActor(new Doge(this, Orientation.DOWN, new DiscreteCoordinates(7, 7)));
	}


	//Randomize the color tiles at the start
	public void randomizeHues() {
		//Randomize
		int random1 = new Random().nextInt(colors.length-2) + 1;
		int random2 = new Random().nextInt(colors.length-2) + 1;
		int random3 = new Random().nextInt(colors.length-2) + 1;
		int random4 = new Random().nextInt(colors.length-2) + 1;

		Hue color1 = colors[random1][random2];
		Hue color2 = colors[random3][random4];
		Vector coords1 = color1.getPosition();
		Vector coords2 = color2.getPosition();
		color1.goToCell(coords2);
		color2.goToCell(coords1);
	}

	@Override
	public String getTitle() {
		return "Webpage.1";
	}

	@Override
	public float getCameraScaleFactor() {
		return Enigme.SCALE_FACTOR;
	}

}
