package ch.epfl.cs107.play.game.enigme;

import ch.epfl.cs107.play.game.areagame.AreaBehavior;
import ch.epfl.cs107.play.game.areagame.actor.Interactable;
import ch.epfl.cs107.play.game.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.window.Image;
import ch.epfl.cs107.play.window.Window;

public class Demo2Behavior extends AreaBehavior {

	Image behaviorMap;

	public Demo2Behavior(Window window, String fileName) {
		super(window, fileName);

		behaviorMap = getBehaviourMap();

		for(int y = 0; y < getHeight(); y++) {
			for(int x = 0; x < getWidth(); x++) {
				int rgb = behaviorMap.getRGB(getHeight() -1-y, x);
				setCell(new Demo2Cell(x, y, Demo2CellType.toType(rgb)), x, y);
			}
		}
	}

	public enum Demo2CellType {
		NULL(0),
		WALL ( -16777216), // RGB code of black
		DOOR(-65536), // RGB code of red
		WATER ( -16776961), // RGB code of blue
		INDOOR_WALKABLE(-1),
		OUTDOOR_WALKABLE ( -14112955);

		final int type;

		Demo2CellType(int type){
			this.type = type ;
		}

		private static Demo2CellType toType(int type) {
			for(Demo2CellType cellType : values()) {
				if(cellType.type == type) return cellType;
			}
			return null;
		}
	}

	public Demo2CellType getCellType(int x, int y) {
		return ((Demo2Cell) getCell(x, y)).type;
	}

	private class Demo2Cell extends Cell {
		Demo2CellType type;

		private Demo2Cell(int x, int y, Demo2CellType type) {
			super(x, y);
			this.type = type;
		}

		public Demo2CellType getCellType() {
			return this.type;
		}

		@Override
		public boolean takeCellSpace() {
			// TODO Auto-generated method stub
			return false;
		}

		@Override
		public boolean isViewInteractable() {
			// TODO Auto-generated method stub
			return false;
		}

		@Override
		public boolean isCellInteractable() {
			// TODO Auto-generated method stub
			return false;
		}

		@Override
		protected boolean canEnter(Interactable interactable) {
			if(this.type == Demo2CellType.NULL || this.type == Demo2CellType.WALL) return false;
			else return true;  
		}

		@Override
		protected boolean canLeave(Interactable interactable) {
			return true;
		}

		@Override
		public void acceptInteraction(AreaInteractionVisitor v) {
			// TODO Auto-generated method stub
			
		}

	}
}