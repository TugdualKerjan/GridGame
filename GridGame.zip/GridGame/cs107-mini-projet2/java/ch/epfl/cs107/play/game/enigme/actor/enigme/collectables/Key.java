package ch.epfl.cs107.play.game.enigme.actor.enigme.collectables;

import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.areagame.actor.Sprite;
import ch.epfl.cs107.play.game.enigme.actor.Collectable;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.signal.logic.Logic;

public class Key extends Collectable implements Logic{

	public Key(Area area, DiscreteCoordinates position) {
		super(area, position);
		setSprite(new Sprite("key.1", 1, 1f, this));
	}
	
}
