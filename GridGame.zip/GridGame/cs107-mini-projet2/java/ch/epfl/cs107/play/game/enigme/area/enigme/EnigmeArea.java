package ch.epfl.cs107.play.game.enigme.area.enigme;

import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.areagame.actor.Background;
import ch.epfl.cs107.play.game.enigme.EnigmeBehavior;
import ch.epfl.cs107.play.io.FileSystem;
import ch.epfl.cs107.play.window.Window;

public abstract class EnigmeArea extends Area {

	@Override
	public boolean begin(Window window, FileSystem fileSystem) {
		super.begin(window, fileSystem);
		setBehavior(new EnigmeBehavior(window, getTitle()));
		//registerActor(new Foreground(this, new RegionOfInterest(0, 0, 1000, 1000), "Enigme0"));
		registerActor(new Background(this));
		return true;
	}
	
	public abstract String getTitle();

	public abstract float getCameraScaleFactor();

}
