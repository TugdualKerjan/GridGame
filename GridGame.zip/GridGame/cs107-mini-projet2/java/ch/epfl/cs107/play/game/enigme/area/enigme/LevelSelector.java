package ch.epfl.cs107.play.game.enigme.area.enigme;

import ch.epfl.cs107.play.game.enigme.Enigme;
import ch.epfl.cs107.play.game.enigme.actor.enigme.SignalDoor;
import ch.epfl.cs107.play.io.FileSystem;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.signal.logic.Logic;
import ch.epfl.cs107.play.window.Window;

public class LevelSelector extends EnigmeArea {

	@Override
	public boolean begin(Window window, FileSystem fileSystem) {
		super.begin(window, fileSystem);
		registerActor(new SignalDoor(this, new DiscreteCoordinates(1, 7), "Level1", new DiscreteCoordinates(5, 1), Logic.TRUE, new DiscreteCoordinates(1, 7)));
		registerActor(new SignalDoor(this, new DiscreteCoordinates(2, 7), "Level2", new DiscreteCoordinates(5, 1), Logic.TRUE, new DiscreteCoordinates(2, 7)));
		registerActor(new SignalDoor(this, new DiscreteCoordinates(3, 7), "Level3", new DiscreteCoordinates(5, 1), Logic.TRUE, new DiscreteCoordinates(3, 7)));
		registerActor(new SignalDoor(this, new DiscreteCoordinates(4, 7), "LevelSelector", new DiscreteCoordinates(5, 5), Logic.FALSE, new DiscreteCoordinates(4, 7)));
		registerActor(new SignalDoor(this, new DiscreteCoordinates(5, 7), "LevelSelector", new DiscreteCoordinates(5, 5), Logic.FALSE, new DiscreteCoordinates(5, 7)));
		registerActor(new SignalDoor(this, new DiscreteCoordinates(6, 7), "LevelSelector", new DiscreteCoordinates(5, 5), Logic.FALSE, new DiscreteCoordinates(6, 7)));
		registerActor(new SignalDoor(this, new DiscreteCoordinates(7, 7), "LevelSelector", new DiscreteCoordinates(5, 5), Logic.FALSE, new DiscreteCoordinates(7, 7)));
		registerActor(new SignalDoor(this, new DiscreteCoordinates(8, 7), "LevelSelector", new DiscreteCoordinates(5, 5), Logic.FALSE, new DiscreteCoordinates(8, 7)));
		
		return true;
	}

	@Override
	public String getTitle() {
		return "LevelSelector";
	}

	@Override
	public float getCameraScaleFactor() {
		// TODO Auto-generated method stub
		return Enigme.SCALE_FACTOR;
	}
}
