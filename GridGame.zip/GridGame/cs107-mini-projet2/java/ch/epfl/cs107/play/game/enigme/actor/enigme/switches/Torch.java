package ch.epfl.cs107.play.game.enigme.actor.enigme.switches;

import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.enigme.actor.enigme.Switch;
import ch.epfl.cs107.play.math.DiscreteCoordinates;

public class Torch extends Switch{

	
	public Torch(Area area, DiscreteCoordinates position) {
		super(area, position, "torch.ground.off", "torch.ground.on.1", "torch.ground.on.2");
	}

	@Override
	public boolean takeCellSpace() {
		return false;
	}

	@Override
	public boolean isViewInteractable() {
		return true;
	}

	@Override
	public boolean isCellInteractable() {
		return false;
	}

}
