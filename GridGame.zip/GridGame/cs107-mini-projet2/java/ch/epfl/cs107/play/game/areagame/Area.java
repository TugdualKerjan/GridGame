package ch.epfl.cs107.play.game.areagame;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import ch.epfl.cs107.play.game.Playable;
import ch.epfl.cs107.play.game.actor.Actor;
import ch.epfl.cs107.play.game.areagame.actor.Interactable;
import ch.epfl.cs107.play.game.areagame.actor.Interactor;
import ch.epfl.cs107.play.game.areagame.actor.MovableAreaEntity;
import ch.epfl.cs107.play.game.areagame.actor.Orientation;
import ch.epfl.cs107.play.game.enigme.actor.enigme.Hue;
import ch.epfl.cs107.play.game.enigme.actor.memes.Doge;
import ch.epfl.cs107.play.io.FileSystem;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.Transform;
import ch.epfl.cs107.play.math.Vector;
import ch.epfl.cs107.play.window.Keyboard;
import ch.epfl.cs107.play.window.Window;


/**
 * Area is a "Part" of the AreaGame. It is characterized by its AreaBehavior and a List of Actors
 */
public abstract class Area implements Playable {
	//Whether game is paused or not
	private boolean paused = false;
	
	//Whether actors can move or not 
	protected boolean noMovement = false;

	// Context objects
	private Window window;
	private FileSystem fileSystem;

	//List of actors
	private List<Actor> actors;

	//List of arriving and leaving actors
	private List <Actor> registeredActors;
	private List <Actor> unregisteredActors;

	private Map<Interactable, List<DiscreteCoordinates>> interactablesToEnter;
	private Map<Interactable, List<DiscreteCoordinates>> interactablesToLeave;

	//List of Interactors
	private List <Interactor> interactors;

	//Actor on which the camera is centered 
	private Actor viewCandidate;

	//Effective center of view;
	private Vector viewCenter;

	//Area behaviour class
	private AreaBehavior areaBehavior;

	//Check if this has ever been instanciated
	public boolean initialized = false;


	protected final void setBehavior(AreaBehavior areaBehavior) {
		this.areaBehavior = areaBehavior;
	}

	public AreaBehavior getBehavior() {
		return areaBehavior;
	}

	/**
	 * Add an actor to the actors list
	 * @param a (Actor): the actor to add, not null
	 * @param forced (Boolean): if true, the method ends
	 */
	private void addActor(Actor a, boolean forced) {
		boolean errorOccured = !actors.add(a);

		if(a instanceof Interactor) errorOccured = errorOccured || !interactors.add((Interactor) a);

		if(a instanceof Interactable) errorOccured = errorOccured || !enterAreaCells(((Interactable) a), ((Interactable) a).getCurrentCells());

		//Error occured and you dont really need actor added, then remove the instance of him off the list
		if(errorOccured && !forced) {
			System.out.println("Actor " + a + " cannot be completely added, so remove it from where it was") ;
			removeActor(a, true);
		}
	}
	
	/**
	 * Remove an actor form the actor list
	 * @param a (Actor): the actor to remove, not null
	 * @param forced (Boolean): if true, the method ends
	 */
	private void removeActor(Actor a, boolean forced){
		boolean errorOccured = !actors.remove(a);

		if(a instanceof Interactor) errorOccured = errorOccured || !interactors.remove((Interactor) a);

		if(a instanceof Interactable) errorOccured = errorOccured || !leaveAreaCells(((Interactable) a), ((Interactable) a).getCurrentCells());

		//Error occured and you dont really need actor added, then remove the instance of him off the list
		if(errorOccured && !forced) {
			System.out.println("Actor " + a + " cannot be completely removed") ;
		}
	}

	/**
	 * Register an actor : will be added at next update
	 * @param a (Actor): the actor to register, not null
	 * @return (boolean): true if the actor is correctly registered
	 */
	public final boolean registerActor(Actor a){
		boolean errorOccured = !registeredActors.add(a);

		if(errorOccured) {
			System.out.println("Actor " + a + " cannot be completely added to registeredActors") ;
		}
		return errorOccured;
	}

	/**
	 * Unregister an actor : will be removed at next update
	 * @param a (Actor): the actor to unregister, not null
	 * @return (boolean): true if the actor is correctly unregistered
	 */
	public final boolean unregisterActor(Actor a){
		boolean errorOccured = !unregisteredActors.add(a);

		if(errorOccured) {
			System.out.println("Actor " + a + " cannot be completely added to unregisteredActors") ;
		}
		return errorOccured;
	}

	/**
	 * Getter for the area width
	 * @return (int) : the width in number of cols
	 */
	public final int getWidth(){
		return areaBehavior.getWidth();
	}

	/**
	 * Getter for the area height
	 * @return (int) : the height in number of rows
	 */
	public final int getHeight(){
		return areaBehavior.getHeight();
	}

	/** @return the Window Keyboard for inputs */
	public final Keyboard getKeyboard () {
		// TODO implements me #PROJECT #TUTO
		return null;
	}

	public final void setViewCandidate(Actor a) {
		this.viewCandidate = a;
	}


	/// Area implements Playable

	@Override
	public boolean begin(Window window, FileSystem fileSystem) {	
		//Initialized to true
		initialized = true;

		//Set the window and filesys vars
		this.window = window;
		this.fileSystem = fileSystem;


		//Scale the window
		Transform viewTransform = Transform.I.scaled(3f).translated(Vector.ZERO);
		window.setRelativeTransform(viewTransform);


		//Init the actors list
		registeredActors = new LinkedList<Actor>();
		unregisteredActors = new LinkedList<Actor>();

		interactablesToEnter = new HashMap<Interactable , List<DiscreteCoordinates>>();
		interactablesToLeave = new HashMap<Interactable , List<DiscreteCoordinates>>();

		interactors = new LinkedList<Interactor>();

		actors = new LinkedList<Actor>();

		//Init viewCandidate and viewCenter
		viewCenter = Vector.ZERO;
		viewCandidate = null;

		return true;
	}

	public final boolean leaveAreaCells(Interactable entity, List<DiscreteCoordinates> coordinates) {
		if(areaBehavior.canLeave(entity, coordinates)) {
			interactablesToLeave.put(entity, coordinates);

			return true;
		} else {
			return false;
		}
	}

	public final boolean enterAreaCells(Interactable entity, List<DiscreteCoordinates> coordinates) {
		if(areaBehavior.canEnter(entity, coordinates) || entity instanceof Hue || entity instanceof Doge) {
			interactablesToEnter.put(entity, coordinates);
			return true;
		} else {
			return false;
		}
	}


	/**
	 * Resume method: Can be overridden
	 * @param window (Window): display context, not null
	 * @param fileSystem (FileSystem): given file system, not null
	 * @return (boolean) : if the resume succeed, true by default
	 */
	public boolean resume(Window window, FileSystem fileSystem){
		paused = false;
		return true;
	}

	@Override
	public void update(float deltaTime) {
		if(paused || noMovement) {
			for(Actor a : actors) {
				a.draw(window);
				if(a instanceof MovableAreaEntity) {
					((MovableAreaEntity) a).resetMotion();
					((MovableAreaEntity) a).setOrientation(Orientation.DOWN);
				}
			}
			return;
		}
		
		purgeRegistration();
		
		updateCamera();

		for(Actor a : actors) {
			a.update(deltaTime);
			a.draw(window);
		}

		for (Interactor interactor : interactors) {
			if (interactor.wantsCellInteraction()) {
				getBehavior().cellInteractionOf(interactor);
			}
			if (interactor.wantsViewInteraction()) {
				getBehavior().viewInteractionOf(interactor);
			}
		}
	}

	private final void purgeRegistration() {
		for(Interactable a : interactablesToLeave.keySet()) {
			areaBehavior.leave(a, interactablesToLeave.get(a));
		}
		for(Interactable a : interactablesToEnter.keySet()) {
			areaBehavior.enter(a, interactablesToEnter.get(a));
		}


		interactablesToEnter.clear();
		interactablesToLeave.clear();
		
		for(Actor a : unregisteredActors) {
			removeActor(a, false);
		}
		for(Actor a : registeredActors) {
			addActor(a, false);
		}


		registeredActors.clear();
		unregisteredActors.clear();
	}

	private void updateCamera () {
		if(viewCandidate != null) {
			viewCenter = viewCandidate.getPosition();
		}
		window.setRelativeTransform(Transform.I.scaled(getCameraScaleFactor()).translated(viewCenter)) ;
	}

	public Vector getViewCenter() {
		return viewCenter;
	}

	public float getCameraScaleFactor() {
		return 1f;
	}

	/**
	 * Suspend method: Can be overridden, called before resume other
	 */
	public void suspend(){
		purgeRegistration();
		paused = true;
	}
	
	public void restart() {
		purgeRegistration();
		actors.clear();
		interactors.clear();
		begin(window, fileSystem);
	}
	
	@Override
	public void end() {
		// TODO save the AreaState somewhere
	}

}
