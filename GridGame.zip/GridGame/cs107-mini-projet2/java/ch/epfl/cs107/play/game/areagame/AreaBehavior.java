package ch.epfl.cs107.play.game.areagame;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import ch.epfl.cs107.play.game.areagame.actor.Interactable;
import ch.epfl.cs107.play.game.areagame.actor.Interactor;
import ch.epfl.cs107.play.game.areagame.io.ResourcePath;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.window.Image;
import ch.epfl.cs107.play.window.Window;

/**
 * AreaBehavior manages a map of Cells.
 */
public abstract class AreaBehavior {

	/// The behavior is an Image of size height x width
	private final Image behaviorMap;
	private final int width, height;

	/// We will convert the image into an array of cells
	private final Cell[][] cells;

	/**
	 * Default AreaBehavior Constructor
	 * @param window (Window): graphic context, not null
	 * @param fileName (String): name of the file containing the behavior image, not null
	 */
	public AreaBehavior(Window window, String fileName) {
		behaviorMap = window.getImage(ResourcePath.getBehaviors(fileName), null, false);

		width = behaviorMap.getWidth();
		height = behaviorMap.getHeight();
		
		cells = new Cell[height][width];
	}

	// TODO implements me #PROJECT #TUTO
	public abstract class Cell implements Interactable {
		public DiscreteCoordinates coords;
		public Set<Interactable> entities;

		public Cell(int x, int y) {
			coords = new DiscreteCoordinates(x, y);
			entities = new HashSet<>();
			entities.add(this);
		}

		public List<DiscreteCoordinates> getCurrentCells() {
			List<DiscreteCoordinates> list = new ArrayList<DiscreteCoordinates>();
			list.add(coords);
			return list;
		}

		private void enter(Interactable interactable) {
			entities.add(interactable);
		}

		private void leave(Interactable interactable) {
			entities.remove(interactable);
		}

		public Set<Interactable> getentities() {
			return entities;
		}

		private void cellInteractionOf(Interactor interactor){
			for(Interactable interactable : entities){
				if(interactable.isCellInteractable())
					interactor.interactWith(interactable);
			}
		}

		private void viewInteractionOf(Interactor interactor) {
			for(Interactable interactable : entities){
				if(interactable.isViewInteractable())
					interactor.interactWith(interactable);
			}
		}

		protected abstract boolean canEnter(Interactable interactable);

		protected abstract boolean canLeave(Interactable interactable);

	}

	public boolean canLeave(Interactable entity, List<DiscreteCoordinates> coordinates) {
		for(DiscreteCoordinates coords : coordinates) {
			//Check if cell in boundaries of area
			if(coords.x < 0 || coords.x > width || coords.y < 0 || coords.y > height) {
				return false;
			}

			//Check if cell at that location agrees to have entity enter
			if(!getCell(coords.x, coords.y).canLeave(entity)) {
				return false;
			}
		}
		return true;
	}

	public boolean canEnter(Interactable entity, List<DiscreteCoordinates> coordinates) {
		for(DiscreteCoordinates coords : coordinates) {
			//Check if cell in boundaries of area
			if(coords.x < 0 || coords.x > width || coords.y < 0 || coords.y > height) {
				return false;
			}

			//Check if cell at that location agrees to have entity enter
			if(!getCell(coords.x, coords.y).canEnter(entity)) {
				return false;
			}
		}
		return true;
	}

	protected void enter(Interactable entity, List<DiscreteCoordinates> coordinates) {
		for(DiscreteCoordinates coords : coordinates) {
			getCell(coords.x, coords.y).enter(entity);
		}

	}

	protected void leave(Interactable entity, List<DiscreteCoordinates> coordinates) {
		for(DiscreteCoordinates coords : coordinates) {
			getCell(coords.x, coords.y).leave(entity);
		}

	}

	public Image getBehaviourMap() {
		return behaviorMap;
	}

	public void cellInteractionOf(Interactor interactor) {
		for(DiscreteCoordinates coords : interactor.getCurrentCells()) {
			getCell(coords.x, coords.y).cellInteractionOf(interactor);
		}
	}

	public void viewInteractionOf(Interactor interactor) {
		for(DiscreteCoordinates coords : interactor.getFieldOfViewCells()) {
			getCell(coords.x, coords.y).viewInteractionOf(interactor);
		}
	}

	public void setCell(Cell cell, int x, int y) {
		cells[y][x] = cell;
	}

	public Cell getCell(int x, int y) {
		if(x < 0 || x > width || y < 0 || y > height) return cells[0][0];
		return cells[y][x];
	}

	public int getWidth() {
		return width;
	}

	public int getHeight() {
		return height;
	}


}
