package ch.epfl.cs107.play.game.enigme.actor.enigme;

import java.util.Collections;
import java.util.List;

import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.areagame.actor.AreaEntity;
import ch.epfl.cs107.play.game.areagame.actor.Orientation;
import ch.epfl.cs107.play.game.areagame.actor.Sprite;
import ch.epfl.cs107.play.game.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.game.enigme.Enigme;
import ch.epfl.cs107.play.game.enigme.handler.EnigmeInteractionVisitor;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.signal.logic.Logic;
import ch.epfl.cs107.play.window.Canvas;

public class PressurePlate extends AreaEntity implements Logic {

	//Frames activated for, here based off frame rate 
	private final int FRAMES_ACTIVATED_FOR = Enigme.FRAMERATE * 2;
	
	//Keeps in mind how long it has lasted
	private int activated = 0;
	
	private Sprite spriteOn;
	private Sprite spriteOff;

	public PressurePlate(Area area, DiscreteCoordinates position) {
		super(area, Orientation.DOWN, position);
		spriteOn = new Sprite("GroundLightOn", 1, 1f, this);
		spriteOff = new Sprite("GroundPlateOff", 1, 1f, this);
	}
	
	@Override
	public boolean takeCellSpace() {
		return true;
	}
	
	@Override
	public boolean isViewInteractable() {
		return false;
	}

	@Override
	public boolean isCellInteractable() {
		return true;
	}

	@Override
	public List<DiscreteCoordinates> getCurrentCells() {
		return Collections.singletonList(getCurrentMainCellCoordinates());
	}

	@Override
	public void acceptInteraction(AreaInteractionVisitor v) {
		((EnigmeInteractionVisitor) v).interactWith(this);
	}

	@Override
	public void draw(Canvas canvas) {
		if(isOn()) spriteOn.draw(canvas);
		else spriteOff.draw(canvas);
	}

	public void activate() {
		activated = FRAMES_ACTIVATED_FOR;
	}
	
	@Override
	public void update(float deltaTime) {
		super.update(deltaTime);
		if(activated > 0) activated--;
	}
	
	@Override
	public boolean isOn() {
		if(activated != 0) return true;
		else return false;
	}


}
