package ch.epfl.cs107.play.game.enigme.actor.enigme;

import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.areagame.actor.Sprite;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.signal.logic.Logic;
import ch.epfl.cs107.play.window.Canvas;

public class WeblinkDoor extends Door implements Logic{
	
	Logic signal;
	Sprite spriteOn;

	public WeblinkDoor(Area area, DiscreteCoordinates position, String spriteName, String destination, DiscreteCoordinates arrivalCoords, Logic signal, DiscreteCoordinates... occupiedCells) {
		super(area, position, destination, arrivalCoords, true, occupiedCells);
		this.signal = signal;
		spriteOn = new Sprite(spriteName, 6f, 1f, this);
	}
	
	@Override
	public void draw(Canvas canvas) {
		if(signal.isOn()) spriteOn.draw(canvas);
	}
	
	@Override
	public boolean takeCellSpace() {
		return !signal.isOn();
	}

	@Override
	public boolean isViewInteractable() {
		return signal.isOn();
	}

	@Override
	public boolean isCellInteractable() {
		return false;
	}

	@Override
	public boolean isOn() {
		return signal.isOn();
	}

}
