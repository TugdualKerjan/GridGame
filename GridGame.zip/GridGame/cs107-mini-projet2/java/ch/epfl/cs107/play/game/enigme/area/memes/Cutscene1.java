package ch.epfl.cs107.play.game.enigme.area.memes;

import ch.epfl.cs107.play.game.areagame.actor.Background;
import ch.epfl.cs107.play.game.enigme.Enigme;
import ch.epfl.cs107.play.game.enigme.Radio;
import ch.epfl.cs107.play.game.enigme.actor.Dialog;
import ch.epfl.cs107.play.io.FileSystem;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.RegionOfInterest;
import ch.epfl.cs107.play.window.Audio;
import ch.epfl.cs107.play.window.Window;

public class Cutscene1 extends CutsceneArea{

	private DiscreteCoordinates arrivalCoords = new DiscreteCoordinates(20, 8);
	
	@Override
	public boolean begin(Window window, FileSystem fileSystem) {
		super.begin(window, fileSystem);
		//Radio.RICK_ASTLEY.play((Audio) window);
		addScene(new Background(this, new RegionOfInterest(0, 0, 640, 640), "Cutscene.1.0"), new Dialog("It's a saturday afternoon, and Veterli was watching tv", "dialog.3", this));
		addScene(new Background(this, new RegionOfInterest(0, 0, 640, 640), "Cutscene.1.1"), new Dialog("BREAKING NEWS: NEW DARK AGE UPON HUMANITY", "dialog.3", this));
		addScene(new Background(this, new RegionOfInterest(0, 0, 640, 640), "Cutscene.1.2"), new Dialog("Today the senate has decided to ban what has arguably kept many people alive in the passing years", "dialog.3", this), new Dialog(" many people alive in the passing years", "dialog.3", this));
		addScene(new Background(this, new RegionOfInterest(0, 0, 640, 640), "Cutscene.1.3"), new Dialog("MEMES.", "dialog.3", this));
		
		addScene(new Background(this, new RegionOfInterest(0, 0, 640, 640), "Cutscene.1.0", 1.0f), 40, new Dialog("I don't feel so good, said Veterli as he magically teleported away", "dialog.3", this));
		addScene(new Background(this, new RegionOfInterest(0, 0, 640, 640), "Cutscene.1.0", 0.9f), 40, new Dialog("I don't feel so good, said Veterli as he magically teleported away", "dialog.3", this));
		addScene(new Background(this, new RegionOfInterest(0, 0, 640, 640), "Cutscene.1.0", 0.8f), 40, new Dialog("I don't feel so good, said Veterli as he magically teleported away", "dialog.3", this));
		addScene(new Background(this, new RegionOfInterest(0, 0, 640, 640), "Cutscene.1.0", .7f), 40, new Dialog("I don't feel so good, said Veterli as he magically teleported away", "dialog.3", this));
		addScene(new Background(this, new RegionOfInterest(0, 0, 640, 640), "Cutscene.1.0", 0.6f), 40, new Dialog("I don't feel so good, said Veterli as he magically teleported away", "dialog.3", this));
		addScene(new Background(this, new RegionOfInterest(0, 0, 640, 640), "Cutscene.1.0", .5f), 40, new Dialog("I don't feel so good, said Veterli as he magically teleported away", "dialog.3", this));
		addScene(new Background(this, new RegionOfInterest(0, 0, 640, 640), "Cutscene.1.0", .4f), 40, new Dialog("I don't feel so good, said Veterli as he magically teleported away", "dialog.3", this));
		addScene(new Background(this, new RegionOfInterest(0, 0, 640, 640), "Cutscene.1.0", 0.3f), 40, new Dialog("I don't feel so good, said Veterli as he magically teleported away", "dialog.3", this));
		addScene(new Background(this, new RegionOfInterest(0, 0, 640, 640), "Cutscene.1.0", .2f), 40, new Dialog("I don't feel so good, said Veterli as he magically teleported away", "dialog.3", this));
		
		return true;
	}

	@Override
	public String getTitle() {
		return "Cutscene1";
	}

	@Override
	public float getCameraScaleFactor() {
		return Enigme.SCALE_FACTOR;
	}

	@Override
	public DiscreteCoordinates getArrivalCoords() {
		return arrivalCoords;
	}

	@Override
	public String getNextTitle() {
		return "Cable.1";
	}
}


