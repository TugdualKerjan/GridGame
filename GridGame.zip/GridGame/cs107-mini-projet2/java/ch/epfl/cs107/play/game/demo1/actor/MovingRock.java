package ch.epfl.cs107.play.game.demo1.actor;

import java.awt.Color;

import ch.epfl.cs107.play.game.actor.GraphicsEntity;
import ch.epfl.cs107.play.game.actor.ImageGraphics;
import ch.epfl.cs107.play.game.actor.TextGraphics;
import ch.epfl.cs107.play.game.areagame.io.ResourcePath;
import ch.epfl.cs107.play.math.Vector;
import ch.epfl.cs107.play.window.Canvas;

public class MovingRock extends GraphicsEntity{

	private final TextGraphics text;
	public static float phi = 0f;
	
	
	public MovingRock(Vector position, String text) {
		super(position, new ImageGraphics(ResourcePath.getSprite("rock.3"), 0.1f, 0.1f, null, Vector.ZERO, 1.0f, -Float.MAX_VALUE));
		this.text = new TextGraphics(text, 0.04f, Color.BLUE);
		this.text.setParent(this);
		this.text.setAnchor(new Vector(0.0f, 0.1f));
	}

	@Override
	public void update(float deltaTime){
		// for simplification , deltaTime ignored :
		//phi += 0.05f;
		
		setCurrentPosition(new Vector((float) Math.cos(phi), (float) Math.sin(phi) * 1.3f));
		text.setAnchor(new Vector((float) Math.cos(phi) * 0.2f - 0.1f, (float) Math.sin(phi) * 0.2f));
	}
	
	@Override
    public void draw(Canvas canvas) {
        if(super.getGraphics() != null) {
            super.draw(canvas);
            text.draw(canvas);
        }
    }


}
