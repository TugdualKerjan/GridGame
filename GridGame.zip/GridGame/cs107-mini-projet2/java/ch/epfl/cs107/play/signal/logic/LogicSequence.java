package ch.epfl.cs107.play.signal.logic;

public class LogicSequence extends LogicSignal{
	
	Logic[] signals;
	int numberAt = 0;
	
	public LogicSequence(Logic... signals) {
		this.signals = signals;
	}
	
	@Override
	public boolean isOn() {
		if(numberAt < signals.length) {
			for(Logic signal : signals) {
				if(signal != signals[numberAt] && signal.isOn()) {
					signal.setOff();
					numberAt = 0;
				}
			}
			if(signals[numberAt].isOn()) {
				signals[numberAt].setOff();
				numberAt++;
				
			}
			return false;
		} 
		return true;
	}

}
