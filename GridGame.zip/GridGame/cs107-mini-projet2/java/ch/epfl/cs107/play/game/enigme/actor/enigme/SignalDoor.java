package ch.epfl.cs107.play.game.enigme.actor.enigme;

import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.areagame.actor.Sprite;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.signal.logic.Logic;
import ch.epfl.cs107.play.window.Canvas;

public class SignalDoor extends Door{

	Logic signal;
	Sprite spriteOff;
	
	public SignalDoor(Area area, DiscreteCoordinates position, String destination, DiscreteCoordinates arrivalCoords, Logic signal, DiscreteCoordinates... occupiedCells) {
		super(area, position, destination, arrivalCoords, occupiedCells);
		this.signal = signal;
		spriteOff = new Sprite("door.close.1", 1, 1f, this);
	}

	@Override
	public boolean takeCellSpace() {
		return signal.isOn();
	}

	@Override
	public boolean isCellInteractable() {
		return signal.isOn();
	}
	
	@Override
	public void draw(Canvas canvas) {
		if(!signal.isOn()) spriteOff.draw(canvas);
		else super.draw(canvas);
	}
}
