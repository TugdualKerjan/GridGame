package ch.epfl.cs107.play.game.enigme.actor.enigme.collectables;

import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.areagame.actor.Sprite;
import ch.epfl.cs107.play.game.enigme.actor.Collectable;
import ch.epfl.cs107.play.math.DiscreteCoordinates;

public class Apple extends Collectable{
	
	public Apple(Area area, DiscreteCoordinates position) {
		super(area, position);
		setSprite(new Sprite("apple.1", 1, 1f, this));
	}
}
