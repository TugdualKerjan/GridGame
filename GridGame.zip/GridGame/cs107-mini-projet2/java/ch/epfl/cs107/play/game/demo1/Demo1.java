package ch.epfl.cs107.play.game.demo1;

import java.awt.Color;

import ch.epfl.cs107.play.game.Game;
import ch.epfl.cs107.play.game.actor.Actor;
import ch.epfl.cs107.play.game.actor.GraphicsEntity;
import ch.epfl.cs107.play.game.actor.ShapeGraphics;
import ch.epfl.cs107.play.game.demo1.actor.MovingRock;
import ch.epfl.cs107.play.io.FileSystem;
import ch.epfl.cs107.play.math.Circle;
import ch.epfl.cs107.play.math.Transform;
import ch.epfl.cs107.play.math.Vector;
import ch.epfl.cs107.play.window.Keyboard;
import ch.epfl.cs107.play.window.Window;

public class Demo1 implements Game{

	private Window window ;
	private FileSystem fileSystem;

	private Actor actor1;
	private Actor actor2;
	
	private Keyboard keyboard;

	@Override
	public boolean begin(Window window, FileSystem fileSystem) {
		this.window = window;
		this.fileSystem = fileSystem;
		keyboard = window.getKeyboard();
		
		Transform viewTransform = Transform.I.scaled(3f).translated(Vector.ZERO);
		window.setRelativeTransform(viewTransform);
		
		actor1 = new GraphicsEntity(Vector.ZERO, new ShapeGraphics(new Circle(0.2f), null, Color.RED, 0.005f));	
		actor2 = new MovingRock(Vector.ZERO, "DANK MEMES");
		return true;
	}

	@Override
	public void end() {
		// TODO Auto-generated method stub

	}

	@Override
	public String getTitle() {
		return "Demo1";
	}

	@Override
	public void update(float deltaTime) {
		if(keyboard.get(Keyboard.DOWN).isDown()) {
			MovingRock.phi += 0.05f;
		} else if (keyboard.get(Keyboard.UP).isDown()) {
			MovingRock.phi -= 0.05f;
		}
		
		if(MovingRock.phi < 0f) {
			
		}
		//Move circle guy around
		actor2.update(deltaTime);
		
		actor1.draw(window);
		actor2.draw(window);
	}

	@Override
	public int getFrameRate() {
		return 30;
	}

}
