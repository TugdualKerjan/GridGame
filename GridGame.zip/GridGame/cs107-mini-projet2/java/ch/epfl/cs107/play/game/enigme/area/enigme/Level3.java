package ch.epfl.cs107.play.game.enigme.area.enigme;

import ch.epfl.cs107.play.game.enigme.Enigme;
import ch.epfl.cs107.play.game.enigme.actor.enigme.PressurePlate;
import ch.epfl.cs107.play.game.enigme.actor.enigme.SignalDoor;
import ch.epfl.cs107.play.game.enigme.actor.enigme.SignalRock;
import ch.epfl.cs107.play.game.enigme.actor.enigme.collectables.Key;
import ch.epfl.cs107.play.game.enigme.actor.enigme.switches.Lever;
import ch.epfl.cs107.play.game.enigme.actor.enigme.switches.PressureSwitch;
import ch.epfl.cs107.play.game.enigme.actor.enigme.switches.Torch;
import ch.epfl.cs107.play.io.FileSystem;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.signal.logic.LogicNumber;
import ch.epfl.cs107.play.signal.logic.MultipleAnd;
import ch.epfl.cs107.play.signal.logic.Or;
import ch.epfl.cs107.play.window.Window;

public class Level3 extends EnigmeArea {

	@Override
	public boolean begin(Window window, FileSystem fileSystem) {
		super.begin(window, fileSystem);
		//Objects
		Key key = new Key(this, new DiscreteCoordinates(1, 3));
		registerActor(key);

		PressurePlate plate = new PressurePlate(this, new DiscreteCoordinates(9, 8));
		registerActor(plate);
		
		PressureSwitch button1 = new PressureSwitch(this, new DiscreteCoordinates(4, 4));
		PressureSwitch button2 = new PressureSwitch(this, new DiscreteCoordinates(5, 4));
		PressureSwitch button3 = new PressureSwitch(this, new DiscreteCoordinates(6, 4));
		PressureSwitch button4 = new PressureSwitch(this, new DiscreteCoordinates(5, 5));
		PressureSwitch button5 = new PressureSwitch(this, new DiscreteCoordinates(4, 6));
		PressureSwitch button6 = new PressureSwitch(this, new DiscreteCoordinates(5, 6));
		PressureSwitch button7 = new PressureSwitch(this, new DiscreteCoordinates(6, 6));
		registerActor(button1);
		registerActor(button2);
		registerActor(button3);
		registerActor(button4);
		registerActor(button5);
		registerActor(button6);
		registerActor(button7);

		Torch torch = new Torch(this, new DiscreteCoordinates(7, 5));
		registerActor(torch);

		Lever lever1 = new Lever(this, new DiscreteCoordinates(10, 5));
		Lever lever2 = new Lever(this, new DiscreteCoordinates(9, 5));
		Lever lever3 = new Lever(this, new DiscreteCoordinates(8, 5));
		registerActor(lever1);
		registerActor(lever2);
		registerActor(lever3);

		//Doors
		registerActor(new SignalDoor(this, new DiscreteCoordinates(5, 9), "LevelSelector", new DiscreteCoordinates(3, 6), key, new DiscreteCoordinates(5, 9)));

		//Rocks
		registerActor(new SignalRock(this, new DiscreteCoordinates(6, 8), plate));
		registerActor(new SignalRock(this, new DiscreteCoordinates(5, 8), new MultipleAnd(button1, button2, button3, button4, button5, button6, button7)));
		registerActor(new SignalRock(this, new DiscreteCoordinates(4, 8), new Or(new LogicNumber(5, lever1, lever2, lever3), torch)));
		return true;
	}

	@Override
	public String getTitle() {
		return "Level3";
	}

	@Override
	public float getCameraScaleFactor() {
		// TODO Auto-generated method stub
		return Enigme.SCALE_FACTOR;
	}
}
