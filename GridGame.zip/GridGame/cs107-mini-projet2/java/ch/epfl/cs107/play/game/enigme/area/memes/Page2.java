package ch.epfl.cs107.play.game.enigme.area.memes;

import ch.epfl.cs107.play.game.enigme.Enigme;
import ch.epfl.cs107.play.game.enigme.Radio;
import ch.epfl.cs107.play.game.enigme.actor.Dialog;
import ch.epfl.cs107.play.game.enigme.actor.enigme.Door;
import ch.epfl.cs107.play.game.enigme.actor.enigme.MusicPressurePlate;
import ch.epfl.cs107.play.game.enigme.actor.enigme.WeblinkDoor;
import ch.epfl.cs107.play.game.enigme.actor.memes.Restart;
import ch.epfl.cs107.play.game.enigme.area.enigme.EnigmeArea;
import ch.epfl.cs107.play.io.FileSystem;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.signal.logic.LogicSequence;
import ch.epfl.cs107.play.window.Canvas;
import ch.epfl.cs107.play.window.Window;

public class Page2 extends EnigmeArea{

	Window window;

	//Initial dialog
	Dialog dialog1 = new Dialog("Welcome! In this challenge, you need to recreate this tune:", "dialog.3", this);
	Dialog dialog2 = new Dialog("Do it by recreating the order of the sounds using the buttons on the left!", "dialog.3", this);
	Dialog dialog3 = new Dialog("To replay the tune, use the button on the right!", "dialog.3", this);
	int startExplain;

	//End dialog
	Dialog dialog4 = new Dialog("AWESOME! Thanks to your help you liberated Rick Astley!", "dialog.3", this);
	Dialog dialog5 = new Dialog("I would play you Never Gonna give you up but unfortunatley", "dialog.3", this);
	Dialog dialog6 = new Dialog("The file is too big for the 1.5MB limit, I had to remove it", "dialog.3", this);
	Dialog dialog7 = new Dialog("Go on the home tile to go back to start", "dialog.3", this);
	int endExplain = 0;

	int timeToPlayTune = 0;

	WeblinkDoor webDoor;

	@Override
	public boolean begin(Window window, FileSystem fileSystem) {
		super.begin(window, fileSystem);
		this.window = window;
		startExplain = Enigme.FRAMERATE * 17;

		//Home and refresh
		registerActor(new Door(this, new DiscreteCoordinates(1, 18), "GameSelector", new DiscreteCoordinates(3, 6), false, new DiscreteCoordinates(1, 18)));
		registerActor(new Restart(this, new DiscreteCoordinates(2, 18)));

		//The musical notes
		MusicPressurePlate button1 = new MusicPressurePlate(this, new DiscreteCoordinates(7, 6), "NOTE1", "button.blue.1", "button.blue.0");
		MusicPressurePlate button2 = new MusicPressurePlate(this, new DiscreteCoordinates(6, 6), "NOTE2", "button.blue.1", "button.blue.0");
		MusicPressurePlate button3 = new MusicPressurePlate(this, new DiscreteCoordinates(4, 6), "NOTE3", "button.blue.1", "button.blue.0");
		MusicPressurePlate button4 = new MusicPressurePlate(this, new DiscreteCoordinates(5, 6), "NOTE4", "button.blue.1", "button.blue.0");
		registerActor(button1);
		registerActor(button2);
		registerActor(button3);
		registerActor(button4);

		MusicPressurePlate button5 = new MusicPressurePlate(this, new DiscreteCoordinates(15, 6), "NONE", "button.red.1", "button.red.0") {
			@Override
			public void activate() {
				activatedFrames = Enigme.FRAMERATE * 1;
				timeToPlayTune = (int) (Enigme.FRAMERATE * 7);
			}

			@Override
			public void draw(Canvas canvas) {
				if(activatedFrames > 0) {
					spriteOn.draw(canvas);
				}
				else spriteOff.draw(canvas);
			}
		};
		registerActor(button5);

		webDoor = new WeblinkDoor(this, new DiscreteCoordinates(7, 12),"weblink.1", "Webpage.3", new DiscreteCoordinates(1, 17),
				new LogicSequence(button1, button2, button3, button3, button4, button1, button2, button3, button3, button2),
				new DiscreteCoordinates(6, 12),
				new DiscreteCoordinates(7, 12),
				new DiscreteCoordinates(8, 12),
				new DiscreteCoordinates(9, 12),
				new DiscreteCoordinates(10, 12),
				new DiscreteCoordinates(11, 12)) {

			private boolean wasJustOn = false;

			@Override
			public void update(float deltaTime) {
				boolean isOn = super.isOn();
				if(isOn && !wasJustOn) {
					Radio.RICK_ASTLEY.play(window, true);
					endExplain = Enigme.FRAMERATE * 16;
				}
				wasJustOn = isOn;
			}
		};
		registerActor(webDoor) ;

		return true;

	}

	@Override
	public String getTitle() {
		return "Webpage.2";
	}

	@Override
	public float getCameraScaleFactor() {
		return Enigme.SCALE_FACTOR;
	}


	@Override
	public void update(float deltaTime) {	
		super.update(deltaTime);
		if(timeToPlayTune > 0) {
			timeToPlayTune--;
			playTune();
		}
		draw();
	}

	private void draw() {
		if(startExplain == Enigme.FRAMERATE * 14) {
			timeToPlayTune = (int) (Enigme.FRAMERATE * 7);
		}
		if(startExplain > Enigme.FRAMERATE * 8) {
			noMovement = true;
			dialog1.draw(window);
			startExplain--;
		} else if(startExplain <= Enigme.FRAMERATE * 9 && startExplain > Enigme.FRAMERATE * 4) {
			dialog2.draw(window);
			startExplain--;
		} else if(startExplain <= Enigme.FRAMERATE * 4 && startExplain > Enigme.FRAMERATE * 0 + 1) {
			dialog3.draw(window);
			startExplain--;
		} if(startExplain == 1) {
			noMovement = false;
			startExplain--;
		} 

		if(endExplain > Enigme.FRAMERATE * 12) {
			noMovement = true;
			dialog4.draw(window);
			endExplain--;
		} else if(endExplain <= Enigme.FRAMERATE * 12 && endExplain > Enigme.FRAMERATE * 8) {
			dialog5.draw(window);
			endExplain--;
		} else if(endExplain <= Enigme.FRAMERATE * 8 && endExplain > Enigme.FRAMERATE * 4) {
			dialog6.draw(window);
			endExplain--;
		} else if(endExplain <= Enigme.FRAMERATE * 4 && endExplain > Enigme.FRAMERATE * 0 + 1) {
			dialog7.draw(window);
			endExplain--;
		} if(endExplain == 1) {
			noMovement = false;
			endExplain--;
		} 
	}

	private void playTune() {
		if(timeToPlayTune == (int) (Enigme.FRAMERATE * 6)) Radio.NOTE1.play(window, true);
		else if(timeToPlayTune == (int) (Enigme.FRAMERATE * 5.4)) Radio.NOTE2.play(window, true);
		else if(timeToPlayTune == (int) (Enigme.FRAMERATE * 4.8)) Radio.NOTE3.play(window, true);
		else if(timeToPlayTune == (int) (Enigme.FRAMERATE * 4.2)) Radio.NOTE3.play(window, true);
		else if(timeToPlayTune == (int) (Enigme.FRAMERATE * 3.6)) Radio.NOTE4.play(window, true);
		else if(timeToPlayTune == (int) (Enigme.FRAMERATE * 3.0)) Radio.NOTE1.play(window, true);
		else if(timeToPlayTune == (int) (Enigme.FRAMERATE * 2.4)) Radio.NOTE2.play(window, true);
		else if(timeToPlayTune == (int) (Enigme.FRAMERATE * 1.8)) Radio.NOTE3.play(window, true);
		else if(timeToPlayTune == (int) (Enigme.FRAMERATE * 1.2)) Radio.NOTE3.play(window, true);
		else if(timeToPlayTune == (int) (Enigme.FRAMERATE * 0.6)) Radio.NOTE2.play(window, true);
	}
}
