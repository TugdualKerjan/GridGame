package ch.epfl.cs107.play.game.enigme.actor;

import java.util.Collections;
import java.util.List;

import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.areagame.actor.AreaEntity;
import ch.epfl.cs107.play.game.areagame.actor.Orientation;
import ch.epfl.cs107.play.game.areagame.actor.Sprite;
import ch.epfl.cs107.play.game.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.game.enigme.handler.EnigmeInteractionVisitor;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.RegionOfInterest;
import ch.epfl.cs107.play.math.Vector;
import ch.epfl.cs107.play.window.Canvas;

public class Sensei extends AreaEntity{

	Sprite sprite;	
	Dialog[] dialogs;
	int dialogNumber = -1;

	public Sensei(Area area, Orientation orientation, DiscreteCoordinates position, Dialog... dialogs) {
		super(area, orientation, position);
		sprite = new Sprite("old.man.1", 1f, 1f, this, new RegionOfInterest(0, 0, 16, 21));
		this.dialogs = dialogs;
	}

	@Override
	public List<DiscreteCoordinates> getCurrentCells() {
		return Collections.singletonList(getCurrentMainCellCoordinates());
	}

	@Override
	public boolean takeCellSpace() {
		return dialogNumber >= dialogs.length;
	}

	@Override
	public boolean isViewInteractable() {
		return true;
	}

	@Override
	public boolean isCellInteractable() {
		return false;
	}

	@Override
	public void acceptInteraction(AreaInteractionVisitor v) {
		((EnigmeInteractionVisitor) v).interactWith(this);
		dialogNumber++;
	}
	
	float alpha = 1f;
	
	@Override
	public void draw(Canvas canvas) {
		//Make him disappear
		if(dialogNumber > dialogs.length - 1) {
			sprite = new Sprite("old.man.1", 1f, 1f, this, new RegionOfInterest(0, 0, 16, 21), Vector.ZERO, alpha, 0f);
			sprite.draw(canvas);
			alpha *= 0.98;
		} else {
			sprite.draw(canvas);
		}
		if(dialogNumber >= 0 && dialogNumber < dialogs.length) {
			dialogs[dialogNumber].draw(canvas);
		}
	}

}
