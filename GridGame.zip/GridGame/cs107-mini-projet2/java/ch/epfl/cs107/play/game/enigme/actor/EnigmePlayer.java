package ch.epfl.cs107.play.game.enigme.actor;

import java.util.Collections;
import java.util.List;

import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.areagame.actor.Animation;
import ch.epfl.cs107.play.game.areagame.actor.Interactable;
import ch.epfl.cs107.play.game.areagame.actor.Interactor;
import ch.epfl.cs107.play.game.areagame.actor.MovableAreaEntity;
import ch.epfl.cs107.play.game.areagame.actor.Orientation;
import ch.epfl.cs107.play.game.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.game.enigme.actor.enigme.Door;
import ch.epfl.cs107.play.game.enigme.actor.enigme.Hue;
import ch.epfl.cs107.play.game.enigme.actor.enigme.MusicPressurePlate;
import ch.epfl.cs107.play.game.enigme.actor.enigme.PressurePlate;
import ch.epfl.cs107.play.game.enigme.actor.enigme.Switch;
import ch.epfl.cs107.play.game.enigme.actor.enigme.switches.PressureSwitch;
import ch.epfl.cs107.play.game.enigme.actor.memes.Doge;
import ch.epfl.cs107.play.game.enigme.actor.memes.Restart;
import ch.epfl.cs107.play.game.enigme.area.memes.Page1;
import ch.epfl.cs107.play.game.enigme.handler.EnigmeInteractionVisitor;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.Vector;
import ch.epfl.cs107.play.window.Canvas;
import ch.epfl.cs107.play.window.Keyboard;

public class EnigmePlayer extends MovableAreaEntity implements Interactor {

	/// Animation duration in frame number
	private final static int ANIMATION_DURATION = 8;

	//Handler for player interaction
	private final EnigmePlayerHandler handler = new EnigmePlayerHandler();

	//Helps for pressureButtons
	private DiscreteCoordinates oldMainCellCoordinates = getCurrentMainCellCoordinates();

	private DiscreteCoordinates dogeCoords = getCurrentMainCellCoordinates();

	//Last door passed through
	private Door door;

	//If he is going through door
	public boolean goingThroughDoor = false;

	//Keyboard to allow user input
	private Keyboard keyboard;

	//Activated when player wants to interact with distance
	private boolean viewInteraction;

	//Add animatior
	Animation animator;

	//Doge to follow you
	Doge doge;

	public boolean restarting = false;

	public EnigmePlayer(Area area, Orientation orientation, DiscreteCoordinates coordinates, Keyboard keyboard) {
		super(area, orientation, coordinates);
		animator = new Animation(4, "max.new.2", 1f, 1f, this, Vector.ZERO, 4, 4, 16, 21);
		this.keyboard = keyboard;
	}

	public EnigmePlayer(Area area, DiscreteCoordinates coordinates, Keyboard keyboard) {
		super(area, Orientation.DOWN, coordinates);
		animator = new Animation(4, "max.new.2", 1f, 1f, this, Vector.ZERO, 4, 4, 16, 21);
		this.keyboard = keyboard;
	}

	//Player enters new area, register actor, set his position, reset his motion and unregister the actor and set the new ownerArea
	public void enterArea(Area area, DiscreteCoordinates position) {
		restarting = false;
		goingThroughDoor = false;

		area.registerActor(this);

		this.setCurrentPosition(new Vector(position.x, position.y));
		this.resetMotion();
		super.setArea(area);

		if(doge != null) {
			area.registerActor(doge);
			doge.setCurrentPosition(new Vector(position.x, position.y - 1));
			doge.setArea(area);
			oldMainCellCoordinates = getCurrentMainCellCoordinates().down();
			dogeCoords = oldMainCellCoordinates;
			doge.setPlayerMainCellCoordinates(dogeCoords);
			System.out.println("wtf");
			doge.resetMotion();
		}
	}

	//Check for keyboard input and super.update
	@Override
	public void update(float deltaTime) {
		if(doge!=null) doge.setCurrentCellCoords(getCurrentMainCellCoordinates());

		if(!oldMainCellCoordinates.equals(getCurrentMainCellCoordinates())) {
			dogeCoords = oldMainCellCoordinates;
			if(doge != null) {
				doge.setPlayerMainCellCoordinates(dogeCoords);
			}
		}


		oldMainCellCoordinates = getCurrentMainCellCoordinates();

		//InteractionS
		viewInteraction = (keyboard.get(Keyboard.L).isPressed()) ?  true : false;

		//Movement
		if(keyboard.get(Keyboard.DOWN).isDown()) {
			if(getOrientation() == Orientation.DOWN) {
				move(ANIMATION_DURATION);
			} else {
				setOrientation(Orientation.DOWN);
			}
		}
		if(keyboard.get(Keyboard.UP).isDown()) {
			if(getOrientation() == Orientation.UP) {
				move(ANIMATION_DURATION);
			} else {
				setOrientation(Orientation.UP);
			}
		}
		if(keyboard.get(Keyboard.LEFT).isDown()) {
			if(getOrientation() == Orientation.LEFT) {
				move(ANIMATION_DURATION);
			} else {
				setOrientation(Orientation.LEFT);
			}
		}
		if(keyboard.get(Keyboard.RIGHT).isDown()) {
			if(getOrientation() == Orientation.RIGHT) {
				move(ANIMATION_DURATION);
			} else {
				setOrientation(Orientation.RIGHT);
			}
		}

		//Update super 
		super.update(deltaTime);
	}

	public void setDoge(Doge dog) {
		doge = dog;
		doge.teleport(dogeCoords);
		doge.setPlayerMainCellCoordinates(dogeCoords);
	}

	//Inform that actor is passing door
	public void setIsPassingDoor(Door door) {
		this.door = door;
		goingThroughDoor = true;
	}

	//Return last passed door
	public Door passedDoor() {
		return door;
	}

	//Draw the actor
	@Override
	public void draw(Canvas canvas) {
		animator.draw(canvas, getOrientation(), isMoving);
	}

	/**
	 * Specific interaction handler for an EnigmePlayer
	 */
	private class EnigmePlayerHandler implements EnigmeInteractionVisitor {

		//Activate going through door process
		@Override
		public void interactWith(Door door) {
			setIsPassingDoor(door);
		}

		//Activate collectables "Pick them up"
		@Override
		public void interactWith(Collectable collectable) {
			collectable.activate();
		}

		//Activate switches
		@Override
		public void interactWith(Switch switcher) {
			//Pressure buttons act slightly differently 
			if(switcher instanceof PressureSwitch) {
				//Check if player just stopped moving
				if(getCurrentMainCellCoordinates() != oldMainCellCoordinates) {
					switcher.activate();
				}
			} else {
				switcher.activate();
			}
		}

		//Pressure plates are special
		@Override
		public void interactWith(PressurePlate plate) {
			plate.activate();
		}

		//Pressure plates are special
		@Override
		public void interactWith(MusicPressurePlate plate) {
			plate.activate();
		}

		@Override
		public void interactWith(Doge doge) {
			setDoge(doge);
			doge.activate();
		}

		//Reload level button
		@Override
		public void interactWith(Restart restart) {
			restarting = true;
		}

		@Override
		public void interactWith(Hue color) {
			if(isMoving) return;
			color.activate();
			((Page1) getArea()).checkIfTwoHuesActivated();
		}
	}

	@Override
	public List<DiscreteCoordinates> getFieldOfViewCells() {
		return Collections.singletonList(getCurrentMainCellCoordinates().jump(getOrientation().toVector()));
	}

	@Override
	public boolean wantsCellInteraction() {
		return true;
	}

	@Override
	public boolean wantsViewInteraction() {
		return viewInteraction;
	}

	@Override
	public void interactWith(Interactable other) {
		other.acceptInteraction(handler);
	}

	@Override
	public List <DiscreteCoordinates > getCurrentCells() {
		return Collections.singletonList(getCurrentMainCellCoordinates());
	}

	@Override
	public boolean takeCellSpace() {
		return false;
	}

	@Override
	public boolean isViewInteractable() {
		return true;
	}

	@Override
	public boolean isCellInteractable() {
		return true;
	}

	@Override
	public void acceptInteraction(AreaInteractionVisitor v) {

	}

}
