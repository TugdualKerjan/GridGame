package ch.epfl.cs107.play.game.enigme;

import ch.epfl.cs107.play.game.areagame.AreaBehavior;
import ch.epfl.cs107.play.game.areagame.actor.Interactable;
import ch.epfl.cs107.play.game.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.game.enigme.handler.EnigmeInteractionVisitor;
import ch.epfl.cs107.play.window.Image;
import ch.epfl.cs107.play.window.Window;

public class EnigmeBehavior extends AreaBehavior {

	Image behaviorMap;

	public EnigmeBehavior(Window window, String fileName) {
		super(window, fileName);

		behaviorMap = getBehaviourMap();

		for(int y = 0; y < getHeight(); y++) {
			for(int x = 0; x < getWidth(); x++) {
				int rgb = behaviorMap.getRGB(getHeight() -1-y, x);
				setCell(new EnigmeCell(x, y, EnigmeCellType.toType(rgb)), x, y);
			}
		}
	}

	public enum EnigmeCellType {
		NULL(0),
		WALL ( -16777216), // RGB code of black
		DOOR(-65536), // RGB code of red
		WATER ( -16776961), // RGB code of blue
		INDOOR_WALKABLE(-1),
		OUTDOOR_WALKABLE ( -14112955);

		final int type;

		EnigmeCellType(int type){
			this.type = type ;
		}

		private static EnigmeCellType toType(int type) {
			for(EnigmeCellType cellType : values()) {
				if(cellType.type == type) return cellType;
			}
			return null;
		}
	}

	public EnigmeCellType getCellType(int x, int y) {
		return getCell(x, y).type;
	}

	public EnigmeCell getCell(int x, int y) {
		return (EnigmeCell) super.getCell(x, y);
	}
	
	public class EnigmeCell extends Cell {
		EnigmeCellType type;

		private EnigmeCell(int x, int y, EnigmeCellType type) {
			super(x, y);
			this.type = type;
		}

		public EnigmeCellType getCellType() {
			return this.type;
		}

		@Override
		public boolean takeCellSpace() {
			return true;
		}

		@Override
		public boolean isViewInteractable() {
			return false;
		}

		@Override
		public boolean isCellInteractable() {
			return false;
		}

		@Override
		protected boolean canEnter(Interactable interactable) {
			for(Interactable actor : entities) {
				if(!actor.takeCellSpace()) {
					return false;
				}
			}
			if(this.type == EnigmeCellType.NULL || this.type == EnigmeCellType.WALL) {
				return false;
			}
			else return true;
		}
		
		@Override
		protected boolean canLeave(Interactable interactable) {
			return true;
		}

		@Override
		public void acceptInteraction(AreaInteractionVisitor v) {
			((EnigmeInteractionVisitor) v).interactWith(this);
		}

	}
}