package ch.epfl.cs107.play.game.enigme.actor.memes;

import java.util.Collections;
import java.util.List;

import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.areagame.actor.Animation;
import ch.epfl.cs107.play.game.areagame.actor.Interactable;
import ch.epfl.cs107.play.game.areagame.actor.MovableAreaEntity;
import ch.epfl.cs107.play.game.areagame.actor.Orientation;
import ch.epfl.cs107.play.game.areagame.actor.Sprite;
import ch.epfl.cs107.play.game.areagame.handler.AreaInteractionVisitor;
import ch.epfl.cs107.play.game.enigme.Enigme;
import ch.epfl.cs107.play.game.enigme.actor.Dialog;
import ch.epfl.cs107.play.game.enigme.actor.enigme.WeblinkDoor;
import ch.epfl.cs107.play.game.enigme.handler.EnigmeInteractionVisitor;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.RegionOfInterest;
import ch.epfl.cs107.play.math.Vector;
import ch.epfl.cs107.play.signal.logic.Logic;
import ch.epfl.cs107.play.window.Canvas;

public class Doge extends MovableAreaEntity implements Interactable{

	final int ANIMATION_DURATION = 4;
	Sprite sprite;
	int started = Enigme.FRAMERATE * 4;
	Animation animator;

	private boolean hasOwner = false;
	
	Dialog dialogWoof = new Dialog("WOOF WOOF", "dialog.3", getArea());
	Dialog dialog1 = new Dialog("Very Wow!! You have liberated the doge from eternal banishment!!!", "dialog.3", getArea());
	Dialog dialogNext = new Dialog("Onto the next challenge!", "dialog.3", getArea());
	
	int dialogTime = 0;

	//Helps for pressureButtons
	private DiscreteCoordinates currentCellCoords = getCurrentMainCellCoordinates();
	private DiscreteCoordinates playerMainCellCoordinates = getCurrentMainCellCoordinates();

	public Doge(Area area, Orientation orientation, DiscreteCoordinates position) {
		super(area, orientation, position);
		sprite = new Sprite("doge.1", 6f, 6f, this, new RegionOfInterest(0, 0, 200, 200), Vector.ZERO, 1f, -3);
		animator = new Animation(1, "mob.3", 1f, 1f, this, Vector.ZERO, 4, 4, 16, 21);
	}

	@Override
	public void update(float deltaTime) {
		if(hasOwner == false) {
			super.update(deltaTime);
			return;
		}
		
		if(getCurrentMainCellCoordinates().jump(Orientation.UP.toVector()).equals(currentCellCoords) ) {
			setOrientation(Orientation.UP);
		}
		if(getCurrentMainCellCoordinates().jump(Orientation.DOWN.toVector()).equals(currentCellCoords)) {
			setOrientation(Orientation.DOWN);
		}
		if(getCurrentMainCellCoordinates().jump(Orientation.RIGHT.toVector()).equals(currentCellCoords)) {
			setOrientation(Orientation.RIGHT);
		}
		if(getCurrentMainCellCoordinates().jump(Orientation.LEFT.toVector()).equals(currentCellCoords)) {
			setOrientation(Orientation.LEFT);
		}

		if(!playerMainCellCoordinates.equals(getCurrentMainCellCoordinates())) {
			move(ANIMATION_DURATION);
		}

		//Update super 
		super.update(deltaTime);
	}

	public void setPlayerMainCellCoordinates(DiscreteCoordinates coords) {
		playerMainCellCoordinates = coords;
	}

	public void setCurrentCellCoords(DiscreteCoordinates coords) {
		currentCellCoords = coords;
	}

	@Override
	protected List<DiscreteCoordinates> getEnteringCells() {
		return getArea().getBehavior().getCell(playerMainCellCoordinates.x, playerMainCellCoordinates.y).getCurrentCells();
	}

	@Override
	public void draw(Canvas canvas) {
		if(started > 1) {
			sprite.draw(canvas);
			dialog1.draw(canvas);
			started--;
		} else {
			animator.draw(canvas, getOrientation(), isMoving);
		}
		
		if(dialogTime >= Enigme.FRAMERATE * 3) {
			dialogWoof.draw(canvas);
			dialogTime--;
		} else if(dialogTime > 1 && dialogTime < Enigme.FRAMERATE * 3) {
			dialogNext.draw(canvas);
			dialogTime--;
		} else if(dialogTime == 1) {
			getArea().registerActor(new WeblinkDoor(getArea(), new DiscreteCoordinates(7, 12),"weblink.1", "Webpage.2", new DiscreteCoordinates(1, 17), Logic.TRUE,
					new DiscreteCoordinates(6, 12),
					new DiscreteCoordinates(7, 12),
					new DiscreteCoordinates(8, 12),
					new DiscreteCoordinates(9, 12),
					new DiscreteCoordinates(10, 12),
					new DiscreteCoordinates(11, 12)));
			dialogTime--;
		}
	}

	@Override
	public List<DiscreteCoordinates> getCurrentCells() {
		return Collections.singletonList(getCurrentMainCellCoordinates());
	}

	@Override
	public boolean takeCellSpace() {
		return hasOwner;
	}

	@Override
	public boolean isViewInteractable() {
		return true;
	}

	@Override
	public boolean isCellInteractable() {
		return !hasOwner;
	}

	@Override
	public void resetMotion() {
		super.resetMotion();
	}

	@Override
	public void setArea(Area area) {
		super.setArea(area);
	}

	@Override
	public void acceptInteraction(AreaInteractionVisitor v) {
		((EnigmeInteractionVisitor) v).interactWith(this);
	}

	public void activate() {
		hasOwner = true;
		dialogTime = Enigme.FRAMERATE * 5;
	}
	
}
