Conception du jeu
=================
#IMPORTANT: J'ai modifiee la classe SwingWindow pour faire en sorte que le jeu soit fullscreen pour etre plus immersif

##1. Generalisations des acteurs

A. J'ai choisit de prendre les acteurs ayant des memes proprietes comme PressureSwitch, Lever and Torch et de les generaliser en creant une super classe 'Switch' de plus mettant les acteurs heritant de cette classe dans leur propre sous package pour faire en sorte que la heirachie soit plus clean

B. Meme chose pour les acteurs ramassables, Apple et Key dans Collectable

##2. Rajout de packages

A. Afin de m'y retrouver entre le project et mes extensions, j'ai sous divisee area et actor dans des packages qui donnent les classes 'fait' pour cette partie du projet

##3. Rajout de un autre constructeur pour background

A. I needed it to display background with a possible alpha

##3. Modif de canEnter 

A. J'ai fait expres de faire en sorte que canEnter exempte la classe Hue de verifier si elle pouvait rentrer car le depth du sprite de Hue est de -1f, donc de pose pas de problem quand elle rentre dans la meme cell que celle du joueur

Extensions
==========

##1. Modifying the font

A. For the A E S T H E T I C S of the game I went into the TextItem class and modified the dont displayed to something more GameBoy ish

##2. Animations

A. Afin de faciliter la tache d'animer les acteurs, ceux qui ne 'montrent' pas leur position ne le demanderont pas dans leur constructeur et passeront Orientaion.DOWN a la super classe

B. La classe Animation permet de faciliter l'animation des sprites: Elle contient deux constructeurs, un qui prend une image composee des sprites et l'autre prend une liste d'images. La classe construit un tableau a partir de ces images, puis grace a la methode 'draw' qui est appellee par les entitees, la classe va faire un cycle de la partie du tableau correspondant a l'orientation pour 'animer' le sprite

C. Le premier parametre framesPerImage permet de ralentir la vitesse a laquelle l'animation ce deroule.

##3. Pausing

A. Afin de avoir un effet stylee et visible quand le joueur pause le jeu, je suis allee dans la classe SwingWindow et j'ai rajoutee un peu de code a la methode update qui verifie si un boolean est vraie ou faux, et, si oui, dessine un blanc transparent pour faire effet 'figee'

##4. Audio

A. J'ai copiee les style des classes ImageGraphics and de ShapeGraphics pour finir de construire la partie audio du projet, Puis J'ai cree la classe enum Radio qui permet a toute classe de jouer un son a tout moment.

##5. Cutscenes

A. J'ai extend la classe EnigmeArea afin de creer une classe dediee a animer des cutscenes qui sont en realitee des background. 

B. J'ai rajoutee l'option de display du texte avec l'image afin d'expliquer le jeux

##6. Doge

A. J'ai rajoutee une classe MovableAreaEntity qui emule le un 'pet'

##7. LogicSequence

A. Extension qui permet de verifier que une serie le signaux logiques sont effectuees un aprea l'autre




