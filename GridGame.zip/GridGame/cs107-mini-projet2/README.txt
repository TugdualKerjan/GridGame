Comment lancer le jeu: Run the Play class
Controles: Arrow keys pour le movement, L pour interagir, SPACE pour pause
Le jeu lancee preentra l'option d'aller vers Enigme qui contient le project demandee, puis Game qui contient le jeu qui presente les extensions
POUR GAGNER A GAME: 
- 1ere page: Remettez dans l'ordre l'image, puis interagir avec le 'chien' pour apres interagir avec le lien vers le prochain niveau
- 2eme page: L'ordre des bouttons c'est: 4 3 1 1 2 4 3 1 1 3 
